const express = require("express");
const { Store } = require("express-session");
const res = require("express/lib/response");
routerOperator = express.Router();
path = require("path");
fs = require("fs");
query = require("../../dbQueries");
Func = require("../../functions");


routerOperator.get("/dashboard", async function (req, res) {
    res.render("Operator/operatorDashboard", {
    });
});

// Add more admin routes here
module.exports = routerOperator;