const express = require("express");
const { Store } = require("express-session");
const res = require("express/lib/response");
routerCompany = express.Router();
path = require("path");
fs = require("fs");
query = require("../../dbQueries");
Func = require("../../functions");


routerCompany.get("/dashboard", async function (req, res) {
    const id = req.query.id;
    const user = await query.fetchUserID(id);
    console.log(user);
    res.render("Company/companyDashboard", {
        user:user,
        backlink:`/company/dashboard?id=${user._id}`
    });
});

routerCompany.get("/plantList", async function (req, res) {
    const id = req.query.id;
    const user = await query.fetchUserID(id);
    const users = await query.fetchAllUsers();
    res.render(`Company/plantList`, {users:users,user:user,id:id
    });
});

routerCompany.post("/editPlant", async function (req, res) {
    const id = req.query.id;
    const userDetails = req.body;
    try {
        const checkEdit = await query.editPlant(userDetails.id,userDetails);
        if (checkEdit) {
            res.redirect(`/company/plantList?id=${id}`);
        } else {
            res.redirect(`../*?error=404&error_desc=Plant not found or already edited`);

        }
    } catch (error) {
        console.error("Error editing plant:", error);
        res.status(500).json({ message: "Internal Server Error", error: error.message });
    }
});

routerCompany.get("/deletePlant", async function (req, res) {
    const deleteId = req.query.id;
    try {
        const checkDelete = await query.deleteUser(deleteId);

        if (checkDelete && checkDelete.deletedCount > 0) {
            res.status(200).json({ message: "Success", deletedId: deleteId });
        } else {
            res.status(404).json({ message: "Plant not found or already deleted" });
        }
    } catch (error) {
        console.error("Error deleting Plant:", error);
        res.status(500).json({ message: "Internal Server Error", error: error.message });
    }
});

routerCompany.get("/plantRegistration", async function (req, res) {
    const id = req.query.id;
    const user = await query.fetchUserID(id);
    console.log("Reg:",id);
    res.render("Company/companyPlant",{id:id , user:user});
});

routerCompany.post('/plantRegistration', async (req, res) => {
    const { plantName, plantIncharge, address, location, phoneNo, AltPhoneNo, email, altEmail,id} = req.body;
    const password = Func.generateRandomPassword(8);
    const userDetails = {
      companyId: id,
      plantName:plantName,
      plantIncharge:plantIncharge,
      address:address,
      location:location,
      phoneNo: phoneNo,
      AltPhoneNo: AltPhoneNo,
      email: email,
      altEmail: altEmail,
      password: password,
      defaultPwd: "1",
      type: "2",
    };
    const user = await query.addUser(userDetails);
    if (user) {
        console.log("User added successfully:", user);
        //Send Mail to the email register with the user name and password
        const emailCheck1 = await Func.SendHtmlDefaultPwd(email,'Welcome to Production Genie !',email,password);
    } else {
        console.log("Failed to add user.");
    }
    console.log('Received form data:', userDetails);
    res.redirect(`/company/plantList?id=${userDetails.companyId}`);
});


// Add more admin routes here
module.exports = routerCompany;