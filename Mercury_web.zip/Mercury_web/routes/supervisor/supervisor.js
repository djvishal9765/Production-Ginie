const express = require("express");
const { Store } = require("express-session");
const res = require("express/lib/response");
routerSupervisor = express.Router();
path = require("path");
fs = require("fs");
query = require("../../dbQueries");
Func = require("../../functions");



routerSupervisor.get("/dashboard", async function (req, res) {
    const id = req.query.id;
    const user = await query.fetchUserID(id);
    console.log(user);
    res.render("Supervisor/supervisorDashboard", {
        user: user,
        backlink: `/supervisor/dashboard?id=${user._id}`
    });
});

//==== User Reg Start
routerSupervisor.get("/userRegistration", async function (req, res) {
    const id = req.query.id;
    const user = await query.fetchUserID(id);
    console.log("Reg:", id);
    res.render("supervisor/userCreation", { id: id, user: user });
});

routerSupervisor.post("/userRegistration", async (req, res) => {
    const {
        userName,
        activityStatus,
        companyId,
        plantId,
        phoneNo,
        AltPhoneNo,
        email,
        adminLevel,
        altEmail,
        id,
    } = req.body;
    const password = Func.generateRandomPassword(8);
    const userDetails = {
        companyId: companyId,
        plantId: plantId,
        userName: userName,
        activityStatus: activityStatus,
        phoneNo: phoneNo,
        AltPhoneNo: AltPhoneNo,
        email: email,
        altEmail: altEmail,
        password: password,
        defaultPwd: "1",
        type: adminLevel,
    };
    const user = await query.addUser(userDetails);
    if (user) {
        //console.log("User added successfully:", user);
        //Send Mail to the email register with the user name and password
        const emailCheck1 = await Func.SendHtmlDefaultPwd(
            email,
            "Welcome to Production Genie !",
            email,
            password
        );
    } else {
        console.log("Failed to add user.");
    }
    res.redirect(`/supervisor/userList?id=${userDetails.plantId}`);
});
//==== User Reg End

//==== User List Start
routerSupervisor.get("/userList", async function (req, res) {
    const id = req.query.id;
    const user = await query.fetchUserID(id);
    const users = await query.fetchAllUsers();
    res.render(`supervisor/userList`, {
        users: users,
        user: user,
        id: user.companyId,
        plantId: user._id,
    });
});

routerSupervisor.post("/editUser", async function (req, res) {
    const id = req.query.id;
    const userDetails = req.body;
    console.log("userDetails = ", userDetails);
    try {
        const checkEdit = await query.editSupervisor(userDetails.id, userDetails);
        if (checkEdit) {
            res.redirect(`/supervisor/userList?id=${id}`);
        } else {
            res.redirect(
                `../*?error=404&error_desc=User not found or already edited`
            );
        }
    } catch (error) {
        console.error("Error editing user:", error);
        res
            .status(500)
            .json({ message: "Internal Server Error", error: error.message });
    }
});

routerSupervisor.get("/deleteUser", async function (req, res) {
    const deleteId = req.query.id;
    try {
        const checkDelete = await query.deleteUser(deleteId);

        if (checkDelete && checkDelete.deletedCount > 0) {
            res.status(200).json({ message: "Success", deletedId: deleteId });
        } else {
            res.status(404).json({ message: "Plant not found or already deleted" });
        }
    } catch (error) {
        console.error("Error deleting Plant:", error);
        res
            .status(500)
            .json({ message: "Internal Server Error", error: error.message });
    }
});
//==== User List End

//==== Tool List Start
routerSupervisor.get("/toolList", async function (req, res) {
    const id = req.query.id;
    const user = await query.fetchUserID(id);
    const tools = await query.fetchTools(user.companyId, user._id.toString());
    res.render(`supervisor/toolList`, {
        tools: tools,
        user: user,
        id: user.companyId,
        plantId: user._id,
    });
});

routerSupervisor.post("/editTool", async function (req, res) {
    const id = req.query.id;
    const userDetails = req.body;

    try {
        const checkEdit = await query.editTool(userDetails.id, userDetails);

        if (checkEdit) {
            res.redirect(`/supervisor/toolList?id=${id}`);
        } else {
            res.redirect(
                `../*?error=404&error_desc=Tool not found or already edited`
            );
        }
    } catch (error) {
        console.error("Error editing tool:", error);
        res
            .status(500)
            .json({ message: "Internal Server Error", error: error.message });
    }
});

routerSupervisor.get("/deleteTool", async function (req, res) {
    const deleteId = req.query.id;
    //   console.log("deleteId ==== ", deleteId);
    try {
        const checkDelete = await query.deleteTool(deleteId);

        if (checkDelete && checkDelete.deletedCount > 0) {
            res.status(200).json({ message: "Success", deletedId: deleteId });
        } else {
            res.status(404).json({ message: "Tool not found or already deleted" });
        }
    } catch (error) {
        console.error("Error deleting tool:", error);
        res
            .status(500)
            .json({ message: "Internal Server Error", error: error.message });
    }
});

//==== Tool List End

//==== Tool Reg Start
routerSupervisor.get("/toolRegistration", async function (req, res) {
    const id = req.query.id;
    const user = await query.fetchUserID(id);
    const users = await query.fetchAllUsers();
    res.render(`supervisor/toolLibrary`, {
        users: users,
        user: user,
        id: user.companyId,
        plantId: user._id,
    });
});

routerSupervisor.post("/toolRegistration", async function (req, res) {
    const id = req.query.id;
    const { toolName, tlLifeHrs, companyId, plantId, toolID, description } =
        req.body;
    const toolDetails = {
        companyId: companyId,
        plantId: plantId,
        toolName: toolName,
        activeStatus: "1",
        toolID: toolID,
        tlLifeHrs: tlLifeHrs,
        currTlLife: "0",
        description: description,
    };
    const tool = await query.addTool(toolDetails);
    res.redirect(`/supervisor/toolList?id=${id}`);
});

//==== Tool Reg End

//==== Reciepe Reg Start
routerSupervisor.get("/recipeRegistration", async function (req, res) {
    const id = req.query.id;
    const user = await query.fetchUserID(id);
    const users = await query.fetchAllUsers();
    const products = await query.fetchProduct(
        user.companyId,
        user._id.toString()
    );
    const tools = await query.fetchTools(user.companyId, user._id.toString());
    res.render(`supervisor/recipeLibrary`, {
        users: users,
        user: user,
        id: user.companyId,
        plantId: user._id,
        products: products,
        tools: tools,
    });
});

routerSupervisor.post("/productRegistration", async function (req, res) {
    const id = req.query.id;
    const productDetails = req.body;

    try {
        const checkAdd = await query.productAdd(productDetails);

        if (checkAdd) {
            res.redirect(`/supervisor/recipeRegistration?id=${id}`);
        } else {
            res.redirect(`../*?error=404&error_desc=Product not added`);
        }
    } catch (error) {
        console.error("Error adding Product:", error);
        res
            .status(500)
            .json({ message: "Internal Server Error", error: error.message });
    }
});

routerSupervisor.post("/recipeRegistration", async function (req, res) {
    const id = req.query.id;
    const recipeDetails = req.body;

    try {
        const checkAdd = await query.recipeAdd(recipeDetails);

        if (checkAdd) {
            res.redirect(`/supervisor/recipeList?id=${id}`);
        } else {
            res.redirect(`../*?error=404&error_desc=Recipe not added`);
        }
    } catch (error) {
        console.error("Error adding Recipe:", error);
        res
            .status(500)
            .json({ message: "Internal Server Error", error: error.message });
    }
});

//==== Reciepe Reg End
//==== Reciepe List Start

routerSupervisor.get("/recipeList", async function (req, res) {
    const id = req.query.id;
    const user = await query.fetchUserID(id);
    const users = await query.fetchAllUsers();
    const products = await query.fetchProduct(
        user.companyId,
        user._id.toString()
    );
    const recipes = await query.fetchRecipes(user.companyId, user._id.toString());
    const tools = await query.fetchTools(user.companyId, user._id.toString());
    // Replace the productName in recipes with the actual productName if it matches the product._id
    recipes.forEach((recipe) => {
        const matchingProduct = products.find(
            (product) => product._id.toString() === recipe.productName
        );
        if (matchingProduct) {
            recipe.productName = matchingProduct.productName;
        }

        const matchingTool = tools.find(
            (tool) => tool._id.toString() === recipe.toolName
        );
        if (matchingTool) {
            recipe.toolName = matchingTool.toolName;
        }
    });

    console.log(recipes);
    res.render(`supervisor/recipeList`, {
        users: users,
        user: user,
        id: user.companyId,
        recipes: recipes,
        products: products,
        tools: tools,
        plantId: user._id,
    });
});

routerSupervisor.get("/deleteRecipe", async function (req, res) {
    const deleteId = req.query.id;
    //   console.log("deleteId ==== ", deleteId);
    try {
        const checkDelete = await query.deleteRecipe(deleteId);

        if (checkDelete && checkDelete.deletedCount > 0) {
            res.status(200).json({ message: "Success", deletedId: deleteId });
        } else {
            res.status(404).json({ message: "Recipe not found or already deleted" });
        }
    } catch (error) {
        console.error("Error deleting Recipe:", error);
        res
            .status(500)
            .json({ message: "Internal Server Error", error: error.message });
    }
});

routerSupervisor.get("/deleteProduct", async function (req, res) {
    const deleteId = req.query.id;
    //   console.log("deleteId ==== ", deleteId);
    try {
        const checkDelete = await query.deleteProduct(deleteId);

        if (checkDelete && checkDelete.deletedCount > 0) {
            res.status(200).json({ message: "Success", deletedId: deleteId });
        } else {
            res.status(404).json({ message: "Product not found or already deleted" });
        }
    } catch (error) {
        console.error("Error deleting Product:", error);
        res
            .status(500)
            .json({ message: "Internal Server Error", error: error.message });
    }
});

routerSupervisor.post("/editRecipe", async function (req, res) {
    const id = req.query.id;
    const recipe = req.body;
    try {
        const checkEdit = await query.editRecipe(recipe.id, recipe);

        if (checkEdit) {
            res.redirect(`/supervisor/recipeList?id=${id}`);
        } else {
            res.redirect(
                `../*?error=404&error_desc=Recipe not found or already edited`
            );
        }
    } catch (error) {
        console.error("Error editing Recipe:", error);
        res
            .status(500)
            .json({ message: "Internal Server Error", error: error.message });
    }

});
//==== Reciepe List End
//==== Shift List Start
routerSupervisor.get("/shiftList", async function (req, res) {
    const id = req.query.id;
    const user = await query.fetchUserID(id);
    const users = await query.fetchAllUsers();
    const shifts = await query.fetchShift(user.companyId, user._id.toString());
    const breaks = await query.fetchBreak(user.companyId, user._id.toString());
    res.render(`supervisor/shiftList`, {
        users: users,
        shifts: shifts,
        breaks: breaks,
        user: user,
        id: user.companyId,
        plantId: user._id,
    });
});

routerSupervisor.get("/deleteShiftBreak", async function (req, res) {
    const deleteId = req.query.id;
    try {
        const checkDelete = await query.deleteShiftBreak(deleteId);

        if (checkDelete && checkDelete.deletedCount > 0) {
            res.status(200).json({ message: "Success", deletedId: deleteId });
        } else {
            res.status(404).json({ message: "Shift not found or already deleted" });
        }
    } catch (error) {
        console.error("Error deleting Shift:", error);
        res
            .status(500)
            .json({ message: "Internal Server Error", error: error.message });
    }
});

routerSupervisor.post("/editShift", async function (req, res) {
    const id = req.query.id;
    const userDetails = req.body;

    try {
        const checkEdit = await query.editShift(userDetails.id, userDetails);

        if (checkEdit) {
            res.redirect(`/supervisor/shiftList?id=${id}`);
        } else {
            res.redirect(
                `../*?error=404&error_desc=Shift not found or already edited`
            );
        }
    } catch (error) {
        console.error("Error editing Shift:", error);
        res
            .status(500)
            .json({ message: "Internal Server Error", error: error.message });
    }
});

routerSupervisor.post("/editBreak", async function (req, res) {
    console.log("Edit Break");
    const id = req.query.id;
    const userDetails = req.body;
    console.log(userDetails);

    try {
        const checkEdit = await query.editBreak(userDetails.id2, userDetails);

        if (checkEdit) {
            res.redirect(`/supervisor/shiftList?id=${id}`);
        } else {
            res.redirect(
                `../*?error=404&error_desc=Break not found or already edited`
            );
        }
    } catch (error) {
        console.error("Error editing Break:", error);
        res
            .status(500)
            .json({ message: "Internal Server Error", error: error.message });
    }
});

//==== Shift List End

routerSupervisor.get("/shiftRegistration", async function (req, res) {
    const id = req.query.id;
    const user = await query.fetchUserID(id);
    const users = await query.fetchAllUsers();
    res.render(`supervisor/shiftSetting`, {
        users: users,
        user: user,
        id: user.companyId,
        plantId: user._id,
    });
});

routerSupervisor.post("/shiftSetting", async function (req, res) {
    const id = req.query.id;
    const user = await query.fetchUserID(id);
    const { shiftName, shiftFrom, companyId, plantId, shiftTo } = req.body;
    const shiftDetails = {
        companyId: companyId,
        plantId: plantId,
        shiftName: shiftName,
        shiftFrom: shiftFrom,
        shiftTo: shiftTo,
        type: "1",
    };
    const users = await query.shiftAdd(shiftDetails);
    res.redirect(`/supervisor/shiftList?id=${id}`);
});

routerSupervisor.post("/breakSetting", async function (req, res) {
    const id = req.query.id;
    const user = await query.fetchUserID(id);
    const { breakName, breakFrom, breakTo, companyId, plantId } = req.body;
    const breakDetails = {
        companyId: companyId,
        plantId: plantId,
        breakName: breakName,
        breakFrom: breakFrom,
        breakTo: breakTo,
        type: "2",
    };
    const users = await query.breakAdd(breakDetails);
    res.redirect(`/supervisor/shiftList?id=${id}`);
});

routerSupervisor.get("/deviceRegistration", async function (req, res) {
    const id = req.query.id;
    const user = await query.fetchUserID(id);
    const users = await query.fetchAllUsers();
    const models = await query.fetchAllModels();
    res.render(`supervisor/deviceRegistration`, {
        users: users,
        user: user,
        id: user.companyId,
        plantId: user._id,
        models: models,
    });
});

routerSupervisor.post("/deviceRegistration", async function (req, res) {
    const id = req.query.id;
    const user = await query.fetchUserID(id);
    console.log("Device Registration", req.body);
    const device = req.body;
    const deviceCheck = await query.deviceAdd(device);
    res.redirect(`/supervisor/deviceList?id=${id}`);
});

routerSupervisor.get("/deviceList", async function (req, res) {
    const id = req.query.id;
    const user = await query.fetchUserID(id);
    const users = await query.fetchAllUsers();
    const devices = await query.fetchDevices(user.companyId, user._id.toString());
    const models = await query.fetchAllModels();

    // Create a mapping from modelId to modelName
    const modelMap = models.reduce((acc, model) => {
        acc[model._id.toString()] = model.modelName;
        return acc;
    }, {});

    // Replace modelId with modelName in devices
    const updatedDevices = devices.map(device => {
        return {
            ...device,
            model: modelMap[device.model] || device.model // Replace model ID with model name, if not found keep the original ID
        };
    });

    console.log("Data:", updatedDevices);

    res.render(`supervisor/deviceList`, {
        users: users,
        user: user,
        id: user.companyId,
        plantId: user._id,
        devices: updatedDevices,
        models: models
    });
});

routerSupervisor.post("/editDevice", async function (req, res) {
    console.log("Edit Device");
    const id = req.query.id;
    const deviceDetails = req.body;

    try {
        const checkEdit = await query.editDevice(deviceDetails.id, deviceDetails);

        if (checkEdit) {
            res.redirect(`/supervisor/deviceList?id=${id}`);
        } else {
            res.redirect(
                `../*?error=404&error_desc=Device not found or already edited`
            );
        }
    } catch (error) {
        console.error("Error editing Device Info:", error);
        res
            .status(500)
            .json({ message: "Internal Server Error", error: error.message });
    }
});



routerSupervisor.get("/deleteDevice", async function (req, res) {
    const deleteId = req.query.id;
    console.log(deleteId);
    try {
        const checkDelete = await query.deleteDevice(deleteId);

        if (checkDelete && checkDelete.deletedCount > 0) {
            res.status(200).json({ message: "Success", deletedId: deleteId });
        } else {
            res.status(404).json({ message: "Device not found or already deleted" });
        }
    } catch (error) {
        console.error("Error deleting Device:", error);
        res
            .status(500)
            .json({ message: "Internal Server Error", error: error.message });
    }
});

routerSupervisor.get("/enableDevice", async function (req, res) {
    const enableId = req.query.id;
    const state = req.query.state;
    console.log("State:", state);
    try {
        const checkDelete = await query.enableDevice(enableId, state);

        if (checkDelete && checkDelete.deletedCount > 0) {
            res.status(200).json({ message: "Success", deletedId: enableId });
        } else {
            res.status(404).json({ message: "Device not found or already deleted" });
        }
    } catch (error) {
        console.error("Error enabling Device:", error);
        res
            .status(500)
            .json({ message: "Internal Server Error", error: error.message });
    }
    //res.send("OK");
});

routerSupervisor.get("/lineAllocation", async function (req, res) {
    const id = req.query.id;
    const user = await query.fetchUserID(id);
    const users = await query.fetchAllUsers();
    const lines = await query.fetchAllLines();
    const products = await query.fetchProduct(user.companyId, user._id.toString());

    const devices = await query.fetchDevices(user.companyId, user._id.toString());
    const allocatedLines = await query.fetchAllocatedLines(user.companyId, user._id.toString());

    const tools = await query.fetchTools(user.companyId, user._id.toString());

    let unallocatedDevices = devices;

    if (allocatedLines && allocatedLines.length > 0) {
        const allocatedDeviceIds = allocatedLines.reduce((acc, line) => {
            return acc.concat(line.deviceId);
        }, []);

        unallocatedDevices = devices.filter(device => !allocatedDeviceIds.includes(device._id.toString()));
    }

    //console.log("available",unallocatedDevices);

    res.render(`supervisor/lineAllocation`, {
        users: users,
        user: user,
        id: user.companyId,
        plantId: user._id,
        products: products,
        tools: tools,
        lines: lines,
        devices: unallocatedDevices,
    });
});

routerSupervisor.post("/lineAllocation", async function (req, res) {
    const id = req.query.id;
    const { plantId, companyId, lineId, deviceId, lineID } = req.body;
    var lineDetails;

    if (Array.isArray(deviceId)) {
        lineDetails = {
            plantId: plantId,
            companyId: companyId,
            lineId: lineId,
            lineID: lineID,
            deviceId: deviceId
        };
    } else {
        lineDetails = {
            plantId: plantId,
            companyId: companyId,
            lineId: lineId,
            lineID: lineID,
            deviceId: [deviceId]
        };
    }

    try {
        const checkAdd = await query.lineAllocation(lineDetails);

        if (checkAdd) {
            res.redirect(`/supervisor/lineList?id=${id}`);
        } else {
            res.redirect(`../*?error=404&error_desc=Line not added`);
        }
    } catch (error) {
        console.error("Error adding Line:", error);
        res
            .status(500)
            .json({ message: "Internal Server Error", error: error.message });
    }
});

routerSupervisor.post("/lineRegistration", async function (req, res) {
    const id = req.query.id;
    const lineDetails = req.body;

    try {
        const checkAdd = await query.lineAdd(lineDetails);

        if (checkAdd) {
            res.redirect(`/supervisor/lineAllocation?id=${id}`);
        } else {
            res.redirect(`../*?error=404&error_desc=Line not added`);
        }
    } catch (error) {
        console.error("Error adding Line:", error);
        res
            .status(500)
            .json({ message: "Internal Server Error", error: error.message });
    }
});

routerSupervisor.get("/lineList", async function (req, res) {
    const id = req.query.id;
    const user = await query.fetchUserID(id);
    const users = await query.fetchAllUsers();
    const products = await query.fetchProduct(
        user.companyId,
        user._id.toString()
    );
    const recipes = await query.fetchRecipes(user.companyId, user._id.toString());
    const tools = await query.fetchTools(user.companyId, user._id.toString());

    const lines = await query.fetchAllLines();
    const allocatedLines = await query.fetchAllocatedLines(user.companyId, user._id.toString());
    const devices = await query.fetchDevices(user.companyId, user._id.toString());
    let unallocatedDevices;
    // Create a map of deviceId to deviceName
    const deviceMap = devices.reduce((map, device) => {
        map[device._id.toString()] = device.deviceName;
        return map;
    }, {});

    const deviceMap2 = devices.reduce((map, device) => {
        map[device._id.toString()] = device.deviceId;
        return map;
    }, {});

    // Add deviceName and LineName to allocatedLines
    const allocatedLinesWithDetails = allocatedLines.map((line) => {
        // Find the matching line to get LineName
        const matchingLine = lines.find(
            (l) => l.lineId.toString() === line.lineId
        );
        const lineName = matchingLine.lineName;

        const deviceNames = line.deviceId.map((deviceId) => deviceMap[deviceId] || 'Unknown'); // Handle cases where deviceName might be missing
        const deviceTemp = line.deviceId.map((deviceId) => deviceMap2[deviceId] || 'Unknown'); // Handle cases where deviceName might be missing

        unallocatedDevices = devices;

        if (allocatedLines && allocatedLines.length > 0) {
            const allocatedDeviceIds = allocatedLines.reduce((acc, line) => {
                return acc.concat(line.deviceId);
            }, []);

            unallocatedDevices = devices.filter(device => !allocatedDeviceIds.includes(device._id.toString()));
        }



        return {
            ...line,
            deviceName: deviceNames, // Add the deviceName key
            lineName: lineName, // Add the LineName key
            deviceId: deviceTemp,
        };
    });

    res.render(`supervisor/lineList`, {
        users: users,
        user: user,
        lines: lines,
        allocatedLines: allocatedLinesWithDetails,
        id: user.companyId,
        recipes: recipes,
        products: products,
        tools: tools,
        plantId: user._id,
        devices: devices,
        unallocatedDevices: unallocatedDevices,
    });
});

routerSupervisor.get("/deleteLine", async function (req, res) {
    const deleteId = req.query.id;
    //   console.log("deleteId ==== ", deleteId);
    try {
        const checkDelete = await query.deleteLine(deleteId);

        if (checkDelete && checkDelete.deletedCount > 0) {
            res.status(200).json({ message: "Success", deletedId: deleteId });
        } else {
            res.status(404).json({ message: "Product not found or already deleted" });
        }
    } catch (error) {
        console.error("Error deleting Product:", error);
        res
            .status(500)
            .json({ message: "Internal Server Error", error: error.message });
    }
});

routerSupervisor.get("/deleteAllocatedLine", async function (req, res) {
    const deleteId = req.query.id;
    const indexId = req.query.index;
    try {
        const checkDelete = await query.deleteLineDevice(deleteId, indexId);

        if (checkDelete && checkDelete.modifiedCount > 0) {
            res.status(200).json({ message: "Success", deletedId: deleteId });
        } else {
            res.status(404).json({ message: "Device not found in Line or already deleted" });
        }
    } catch (error) {
        console.error("Error deleting Device from Line:", error);
        res
            .status(500)
            .json({ message: "Internal Server Error", error: error.message });
    }
});

routerSupervisor.post("/editAllocatedLine", async function (req, res) {
    console.log("Edit Allocated Lines");
    const id = req.query.id;
    const LineDetails = req.body;

    const devices = await query.fetchDeviceById(LineDetails.preDeviceId);
    try {
        const index = await query.getDeviceIdArrayIndex(LineDetails.id, devices._id);

        const result = await query.updateDeviceInLine(LineDetails.id, devices._id, LineDetails.editDeviceId, index);
        if (result) {
            res.redirect(`/supervisor/lineList?id=${id}`);
        } else {
            res.redirect(
                `../*?error=404&error_desc=Device not found or already edited`
            );
        }
    } catch (error) {
        console.error("Error editing Device Info:", error);
        res
            .status(500)
            .json({ message: "Internal Server Error", error: error.message });
    }

});

routerSupervisor.post("/editLine", async function (req, res) {
    const deleteId = req.query.id;
    const LineDetails = req.body;
    const id = req.query.id;
    try {
        const devices = await query.editLineMain(LineDetails.LineIdGot, LineDetails.LineIdEdit, LineDetails.LineNameEdit);
        const Line = await query.fetchAllocatedLineById(LineDetails.LineIdGot);
        const devices2 = await query.editLineAllocation(Line._id, LineDetails.LineIdEdit);
        if (devices2) {
            res.redirect(`/supervisor/lineList?id=${id}`);
        } else {
            res.redirect(
                `../*?error=404&error_desc=Device not found or already edited`
            );
        }
    } catch (error) {
        console.error("Error editing Device Info:", error);
        res
            .status(500)
            .json({ message: "Internal Server Error", error: error.message });
    }

});

routerSupervisor.get("/dailyPlanning", async function (req, res) {
    const id = req.query.id;
    const user = await query.fetchUserID(id);
    const users = await query.fetchAllUsers();
    const lines = await query.fetchAllLines();
    const products = await query.fetchProduct(user.companyId, user._id.toString());
    const shifts = await query.fetchShift(user.companyId, user._id.toString());
    const breaks = await query.fetchBreak(user.companyId, user._id.toString());
    const devices = await query.fetchDevices(user.companyId, user._id.toString());
    const allocatedLines = await query.fetchAllocatedLines(user.companyId, user._id.toString());
    const recipes = await query.fetchRecipes(user.companyId, user._id.toString());

    // console.log("devices === ", devices);

    const tools = await query.fetchTools(user.companyId, user._id.toString());

    res.render(`supervisor/dailyPlanning`, {
        users: users,
        user: user,
        id: user.companyId,
        plantId: user._id,
        products: products,
        shifts: shifts,
        breaks: breaks,
        tools: tools,
        lines: lines,
        devices: devices,
        allocatedLines: allocatedLines,
        recipes: recipes
    });
});

routerSupervisor.post("/dailyPlanning", async function (req, res) {
    const id = req.query.id;
    const Details = req.body;

    try {
        const checkAdd = await query.dailyPlanning(Details);

        if (checkAdd) {
            res.redirect(`/supervisor/todaysPlanning?id=${id}`);
        } else {
            res.redirect(`../*?error=404&error_desc= not added`);
        }
    } catch (error) {
        console.error("Error adding:", error);
        res
            .status(500)
            .json({ message: "Internal Server Error", error: error.message });
    }
});

routerSupervisor.get("/todaysPlanning", async function (req, res) {
    const id = req.query.id;
    const user = await query.fetchUserID(id);
    const users = await query.fetchAllUsers();
    const lines = await query.fetchAllLines();
    const products = await query.fetchProduct(user.companyId, user._id.toString());
    const shifts = await query.fetchShift(user.companyId, user._id.toString());
    const breaks = await query.fetchBreak(user.companyId, user._id.toString());
    const devices = await query.fetchDevices(user.companyId, user._id.toString());
    const allocatedLines = await query.fetchAllocatedLines(user.companyId, user._id.toString());
    const recipes = await query.fetchRecipes(user.companyId, user._id.toString());

    // console.log("devices === ", devices);

    const tools = await query.fetchTools(user.companyId, user._id.toString());

    res.render(`supervisor/todaysPlanning`, {
        users: users,
        user: user,
        id: user.companyId,
        plantId: user._id,
        products: products,
        shifts: shifts,
        breaks: breaks,
        tools: tools,
        lines: lines,
        devices: devices,
        allocatedLines: allocatedLines,
        recipes: recipes
    });
});

// Add more admin routes here
module.exports = routerSupervisor;