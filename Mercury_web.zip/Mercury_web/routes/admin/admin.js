const express = require("express");
const { Store } = require("express-session");
const res = require("express/lib/response");
routerAdmin = express.Router();
path = require("path");
fs = require("fs");
query = require("../../dbQueries");
Func = require("../../functions");


routerAdmin.get("/dashboard", async function (req, res) {
    res.render("Mercury/mercDashboard", {
    });
});

// List Company Route : Start
routerAdmin.get("/companyList", async function (req, res) {
    const users = await query.fetchAllUsers();
    res.render("Mercury/companyList", {users:users
    });
});


routerAdmin.post("/editCompany", async function (req, res) {
    const userDetails = req.body;
    console.log("userDetails =====",userDetails);
    try {
        const checkEdit = await query.editUser(userDetails.id,userDetails);
        if (checkEdit) {
            res.redirect("/admin/companyList");
        } else {
            res.redirect(`../*?error=404&error_desc=User not found or already edited`);

        }
    } catch (error) {
        console.error("Error editing company:", error);
        res.status(500).json({ message: "Internal Server Error", error: error.message });
    }
});

routerAdmin.get("/deleteCompany", async function (req, res) {
    const deleteId = req.query.id;
    try {
        const checkDelete = await query.deleteUser(deleteId);

        if (checkDelete && checkDelete.deletedCount > 0) {
            res.status(200).json({ message: "Success", deletedId: deleteId });
        } else {
            res.status(404).json({ message: "User not found or already deleted" });
        }
    } catch (error) {
        console.error("Error deleting company:", error);
        res.status(500).json({ message: "Internal Server Error", error: error.message });
    }
});

// List Company Route : End

routerAdmin.get("/companyRegistration", async function (req, res) {
    res.render("Mercury/companyRegistration", {
    });
});

routerAdmin.post("/companyRegistration", async function (req, res) {
    const {companyName , contactNo , Address ,Plan , Website,phoneNo,AltPhoneNo,email,altEmail} = req.body;
    const password = Func.generateRandomPassword(8);
    const userDetails = {
      companyName: companyName,
      contactNo: contactNo,
      Address: Address,
      Plan: Plan,
      Website: Website,
      phoneNo: phoneNo,
      AltPhoneNo: AltPhoneNo,
      email: email,
      altEmail: altEmail,
      password: password,
      defaultPwd: "1",
      type: "1",
    };
    const user = await query.addUser(userDetails);
    if (user) {
        console.log("User added successfully:", user);
        //Send Mail to the email register with the user name and password
        const emailCheck1 = await Func.SendHtmlDefaultPwd(email,'Welcome to Production Genie !',email,password);
    } else {
        console.log("Failed to add user.");
    }
    res.redirect("/admin/companyList");
});

// Add more admin routes here

module.exports = routerAdmin;
