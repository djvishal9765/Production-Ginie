const express = require("express");
const { Store } = require("express-session");
const res = require("express/lib/response");
const util = require("util");
routerPlant = express.Router();
path = require("path");
fs = require("fs");
query = require("../../dbQueries");
Func = require("../../functions");
//==== Dashboard Start

routerPlant.use(express.json());

routerPlant.get("/dashboard", async function (req, res) {
  try {
    console.log("Received request to /dashboard with query:", req.query);

    // Extract the ID from the query parameter
    const id = req.query.id;
    if (!id) {
      console.error("Error: 'id' query parameter is missing.");
      return res.status(400).send("Error: 'id' query parameter is required.");
    }

    console.log("Fetching user data for ID:", id);

    // Fetch the user data using the provided ID
    const user = await query.fetchUserID(id);

    if (!user) {
      console.warn("No user found for the provided ID:", id);
      return res.status(404).send("Error: User not found.");
    }

    console.log("User data fetched successfully:", user);

    // Extract the name from the user object
    const userName = user.name || "Unknown User"; // Replace with actual field for the name

    console.log("Fetched user name:", userName);

    const backlink = `/plant/dashboardDashboard?id=${user._id}`;
    console.log("Constructed backlink:", backlink);

    // Render the dashboard with user name and backlink
    res.render("Plant/plantDashboard", {
      user: { ...user, name: userName },
      backlink: backlink,
    });

    console.log("Successfully rendered plantDashboard with user data.");
  } catch (error) {
    console.error("Error while processing /dashboard request:", error);
    res.status(500).send("Internal Server Error");
  }
});

routerPlant.get("/plantDashboard", async function (req, res) {
  try {
    console.log("Entering /plantDashboard route");

    const id = req.query.id;
    console.log("Received query parameter 'id':", id);

    console.log("Fetching user data for ID:", id);
    const user = await query.fetchUserID(id);

    if (user) {
      console.log("Fetched user data:", user);
    } else {
      console.warn("No user found with ID:", id);
    }

    console.log("Rendering plantDashboard2 view with user data");
    res.render("Plant/plantDashboard2", {
      user: user,
      backlink: `/plant/dashboardDashboard?id=${user ? user._id : "unknown"}`,
    });

    console.log("Successfully rendered plantDashboard2");
  } catch (error) {
    console.error("Error in /plantDashboard route:", error);

    res.status(500).send("An error occurred while processing your request.");
  }
});

routerPlant.get("/devicedashboard", async function (req, res) {
  try {
    const id = req.query.id;
    console.log("ID === ", id);
    const user = await query.fetchUserID(id);
    console.log("USER === ", user);
    const devices = await query.fetchDevices(
      user.companyId,
      user._id.toString()
    );
    console.log("DEVICES === ", devices);
    const lines = await query.fetchAllLines(
      user.companyId,
      user._id.toString()
    );
    console.log("LINES === ", lines);
    const startTimeRaw = await query.fetchStartLogs(
      user.companyId,
      user._id.toString()
    );
    console.log("START TIME ROW === ", startTimeRaw);
    const startTime = startTimeRaw.map((item) => ({
      deviceId: item.deviceId,
      time: item.time,
    }));
    console.log("START TIME === ", startTime);
    const DateTime = await Func.getCurrentDateTime();
    console.log("DATE AND TIME === ", DateTime);
    const tools = await query.fetchTools(user.companyId, user._id.toString());
    const finalPlanning = await query.fetchFinalPlanning(
      user.companyId,
      user._id.toString(),
      DateTime.date
    );
    const allShifts = await query.fetchShift(
      user.companyId,
      user._id.toString()
    );
    const currentShiftId = await Func.getCurrentShift(DateTime, allShifts);
    const currentShift = allShifts.find(
      (shift) => shift._id.toString() === currentShiftId
    );
    const shiftFromTime = currentShift ? currentShift.shiftFrom : "N/A";
    if (finalPlanning.length === 0) {
      console.warn("Planning not Found");
    } else {
      if (!finalPlanning[0].deviceId || !finalPlanning[0].deviceId.length) {
        console.error(
          "Invalid finalPlanning data: Missing or empty deviceId array"
        );
        throw new Error(
          "Invalid finalPlanning data: Missing or empty deviceId array"
        );
      }
      for (let i = 0; i < finalPlanning[0].deviceId.length; i++) {
        finalPlanning[0].deviceId[i] = await query.fetchDeviceByObjId(
          finalPlanning[0].deviceId[i]
        );

        finalPlanning[0].lineId[i] = await query.fetchLineByOgId(
          finalPlanning[0].lineId[i]
        );

        finalPlanning[0].recipeId[i] = await query.fetchRecipesById(
          finalPlanning[0].recipeId[i]
        );

        finalPlanning[0].shiftId[i] = await query.fetchShiftById(
          finalPlanning[0].shiftId[i]
        );

        finalPlanning[0].productName[i] = await query.fetchProductById(
          finalPlanning[0].productName[i]
        );
      }
    }

    res.render("Plant/deviceDashboard", {
      user: user,
      backlink: `/plant/dashboard?id=${user._id}`,
      lines: lines,
      finalPlanning: finalPlanning,
      devices: devices,
      tools: tools,
      startTime: JSON.stringify(startTime),
      shiftFrom: shiftFromTime,
    });
    console.log("Rendered Plant/deviceDashboard successfully");
  } catch (error) {
    console.error("Error in /devicedashboard route:", error.message);
    console.error(error.stack);
    res.status(500).send("An error occurred while processing the request.");
  }
});

routerPlant.get("/lineDashboard", async function (req, res) {
  const id = req.query.id;
  // console.log(
  //   "ID PLANT *****************************************************************************",
  //   id
  // );
  const user = await query.fetchUserID(id);
  const lines = await query.fetchAllLines(user.companyId, user._id.toString());
  const DateTime = await Func.getCurrentDateTime();
  const finalPlanning = await query.fetchFinalPlanning(
    user.companyId,
    user._id.toString(),
    DateTime.date
  );

  if (finalPlanning.length === 0) {
    console.log("Planning not Found");
  } else {
    if (!finalPlanning[0].deviceId || !finalPlanning[0].deviceId.length) {
      throw new Error(
        "Invalid finalPlanning data: Missing or empty deviceId array"
      );
    }
    for (let i = 0; i < finalPlanning[0].deviceId.length; i++) {
      const deviceDetail = await query.fetchDeviceByObjId(
        finalPlanning[0].deviceId[i]
      );
      const lineDetail = await query.fetchLineByOgId(
        finalPlanning[0].lineId[i]
      );
      const productDetail = await query.fetchRecipesById(
        finalPlanning[0].recipeId[i]
      );
      const shiftDetail = await query.fetchShiftById(
        finalPlanning[0].shiftId[i]
      );

      const recipeDetail = await query.fetchProductById(
        finalPlanning[0].productName[i]
      );
      finalPlanning[0].deviceId[i] = deviceDetail;
      finalPlanning[0].lineId[i] = lineDetail;
      finalPlanning[0].recipeId[i] = productDetail;
      finalPlanning[0].shiftId[i] = shiftDetail;
      finalPlanning[0].productName[i] = recipeDetail;
    }
  }

  // console.log(
  //   "Final Planning::",
  //   util.inspect(finalPlanning, { depth: null, colors: true })
  // );
  res.render("Plant/lineDashboard", {
    user: user,
    backlink: `/plant/dashboard?id=${user._id}`,
    lines: lines,
    finalPlanning: finalPlanning,
  });
});

routerPlant.get("/finalData", async function (req, res) {
  const id = req.query.id;
  const maxRetries = 5; // Set max retries
  const retryDelay = 1000; // Delay in ms (1 second)

  let user = null;
  let attempts = 0;

  while (user === null && attempts < maxRetries) {
    // console.log(`Attempt ${attempts + 1}: Fetching user ID...`);

    user = await query.fetchUserID(id);

    if (user === null) {
      console.log(
        `User fetch failed. Retrying in ${retryDelay / 1000} seconds...`
      );
      await new Promise((resolve) => setTimeout(resolve, retryDelay)); // Wait before retrying
    }

    attempts++;
  }

  if (user === null) {
    console.error("Failed to fetch user after multiple attempts.");
  } else {
    // console.log("User fetched successfully:", user);
  }
  if (user) {
    // console.log("USER ID ======", id);
    // console.log("USER ======", user);
    const lines = await query.fetchAllLines(
      user.companyId,
      user._id.toString()
    );
    const DateTime = await Func.getCurrentDateTime();
    const finalPlanning = await query.fetchFinalPlanning(
      user.companyId,
      user._id.toString(),
      DateTime.date
    );

    // console.log(
    //   "**************Final Planning for line dashboard****************",
    //   finalPlanning
    // );

    if (!finalPlanning || finalPlanning.length === 0) {
      console.log("Planning not Found");
    } else {
      const deviceIds = finalPlanning[0]?.deviceId; // Using optional chaining
      if (!Array.isArray(deviceIds) || deviceIds.length === 0) {
        throw new Error(
          "Invalid finalPlanning data: Missing or empty deviceId array"
        );
      }
      for (let i = 0; i < finalPlanning[0].deviceId.length; i++) {
        const deviceDetail = await query.fetchDeviceByObjId(
          finalPlanning[0].deviceId[i]
        );
        const lineDetail = await query.fetchLineByOgId(
          finalPlanning[0].lineId[i]
        );
        const productDetail = await query.fetchRecipesById(
          finalPlanning[0].recipeId[i]
        );
        const shiftDetail = await query.fetchShiftById(
          finalPlanning[0].shiftId[i]
        );

        const recipeDetail = await query.fetchProductById(
          finalPlanning[0].productName[i]
        );
        finalPlanning[0].deviceId[i] = deviceDetail;
        finalPlanning[0].lineId[i] = lineDetail;
        finalPlanning[0].recipeId[i] = productDetail;
        finalPlanning[0].shiftId[i] = shiftDetail;
        finalPlanning[0].productName[i] = {
          ...recipeDetail,
          process: productDetail?.process || "", // Extract process from productDetail
        };
      }
    }
    // console.log(
    //   "Final Planning::",
    //   util.inspect(finalPlanning, { depth: null, colors: true })
    // );
    res.send(finalPlanning);
  }
});

routerPlant.get("/finalData2", async function (req, res) {
  const id = req.query.id;
  const user = await query.fetchUserID(id);
  const lines = await query.fetchAllLines(user.companyId, user._id.toString());
  const DateTime = await Func.getCurrentDateTime();
  const finalPlanning = await query.fetchFinalPlanning(
    user.companyId,
    user._id.toString(),
    DateTime.date
  );

  if (finalPlanning === null || finalPlanning.length === 0) {
    console.log("Planning not Found");
  } else {
    if (!finalPlanning[0].deviceId || !finalPlanning[0].deviceId.length) {
      throw new Error(
        "Invalid finalPlanning data: Missing or empty deviceId array"
      );
    }
    for (let i = 0; i < finalPlanning[0].deviceId.length; i++) {
      const deviceDetail = await query.fetchDeviceByObjId(
        finalPlanning[0].deviceId[i]
      );
      const lineDetail = await query.fetchLineByOgId(
        finalPlanning[0].lineId[i]
      );
      const productDetail = await query.fetchRecipesById(
        finalPlanning[0].recipeId[i]
      );
      const shiftDetail = await query.fetchShiftById(
        finalPlanning[0].shiftId[i]
      );

      const recipeDetail = await query.fetchProductById(
        finalPlanning[0].productName[i]
      );
      finalPlanning[0].deviceId[i] = deviceDetail;
      finalPlanning[0].lineId[i] = lineDetail;
      finalPlanning[0].recipeId[i] = productDetail;
      finalPlanning[0].shiftId[i] = shiftDetail;
      finalPlanning[0].productName[i] = recipeDetail;
    }
  }

  // console.log("Final Planning::", util.inspect(finalPlanning, { depth: null, colors: true }));
  res.send(finalPlanning);
});

//==== Dashboard End

//==== User Reg Start
routerPlant.get("/userRegistration", async function (req, res) {
  const id = req.query.id;
  const user = await query.fetchUserID(id);
  console.log("Reg:", id);
  res.render("Plant/userCreation", { id: id, user: user });
});

routerPlant.post("/userRegistration", async (req, res) => {
  const {
    userName,
    activityStatus,
    companyId,
    plantId,
    phoneNo,
    AltPhoneNo,
    email,
    adminLevel,
    altEmail,
    id,
  } = req.body;
  const password = Func.generateRandomPassword(8);
  const userDetails = {
    companyId: companyId,
    plantId: plantId,
    userName: userName,
    activityStatus: activityStatus,
    phoneNo: phoneNo,
    AltPhoneNo: AltPhoneNo,
    email: email,
    altEmail: altEmail,
    password: password,
    defaultPwd: "1",
    type: adminLevel,
  };
  const user = await query.addUser(userDetails);
  if (user) {
    //console.log("User added successfully:", user);
    //Send Mail to the email register with the user name and password
    const emailCheck1 = await Func.SendHtmlDefaultPwd(
      email,
      "Welcome to Production Genie !",
      email,
      password
    );
  } else {
    console.log("Failed to add user.");
  }
  res.redirect(`/plant/userList?id=${userDetails.plantId}`);
});
//==== User Reg End

//==== User List Start
routerPlant.get("/userList", async function (req, res) {
  const id = req.query.id;
  const user = await query.fetchUserID(id);
  const users = await query.fetchAllUsers();
  res.render(`Plant/userList`, {
    users: users,
    user: user,
    id: user.companyId,
    plantId: user._id,
  });
});

routerPlant.post("/editUser", async function (req, res) {
  const id = req.query.id;
  const userDetails = req.body;
  console.log("userDetails = ", userDetails);
  try {
    const checkEdit = await query.editSupervisor(userDetails.id, userDetails);
    if (checkEdit) {
      res.redirect(`/plant/userList?id=${id}`);
    } else {
      res.redirect(
        `../*?error=404&error_desc=User not found or already edited`
      );
    }
  } catch (error) {
    console.error("Error editing user:", error);
    res
      .status(500)
      .json({ message: "Internal Server Error", error: error.message });
  }
});

routerPlant.get("/deleteUser", async function (req, res) {
  const deleteId = req.query.id;
  try {
    const checkDelete = await query.deleteUser(deleteId);

    if (checkDelete && checkDelete.deletedCount > 0) {
      res.status(200).json({ message: "Success", deletedId: deleteId });
    } else {
      res.status(404).json({ message: "Plant not found or already deleted" });
    }
  } catch (error) {
    console.error("Error deleting Plant:", error);
    res
      .status(500)
      .json({ message: "Internal Server Error", error: error.message });
  }
});
//==== User List End

//==== Tool List Start
routerPlant.get("/toolList", async function (req, res) {
  const id = req.query.id;
  const user = await query.fetchUserID(id);
  const tools = await query.fetchTools(user.companyId, user._id.toString());
  res.render(`Plant/toolList`, {
    tools: tools,
    user: user,
    id: user.companyId,
    plantId: user._id,
  });
});

routerPlant.post("/editTool", async function (req, res) {
  const id = req.query.id;
  const userDetails = req.body;

  try {
    const checkEdit = await query.editTool(userDetails.id, userDetails);

    if (checkEdit) {
      res.redirect(`/plant/toolList?id=${id}`);
    } else {
      res.redirect(
        `../*?error=404&error_desc=Tool not found or already edited`
      );
    }
  } catch (error) {
    console.error("Error editing tool:", error);
    res
      .status(500)
      .json({ message: "Internal Server Error", error: error.message });
  }
});

routerPlant.get("/deleteTool", async function (req, res) {
  const deleteId = req.query.id;
  //   console.log("deleteId ==== ", deleteId);
  try {
    const checkDelete = await query.deleteTool(deleteId);

    if (checkDelete && checkDelete.deletedCount > 0) {
      res.status(200).json({ message: "Success", deletedId: deleteId });
    } else {
      res.status(404).json({ message: "Tool not found or already deleted" });
    }
  } catch (error) {
    console.error("Error deleting tool:", error);
    res
      .status(500)
      .json({ message: "Internal Server Error", error: error.message });
  }
});

//==== Tool List End

//==== Tool Reg Start
routerPlant.get("/toolRegistration", async function (req, res) {
  const id = req.query.id;
  const user = await query.fetchUserID(id);
  const users = await query.fetchAllUsers();
  res.render(`Plant/toolLibrary`, {
    users: users,
    user: user,
    id: user.companyId,
    plantId: user._id,
  });
});

routerPlant.post("/toolRegistration", async function (req, res) {
  const id = req.query.id;
  const { toolName, tlLifeHrs, companyId, plantId, toolID, description } =
    req.body;
  const toolDetails = {
    companyId: companyId,
    plantId: plantId,
    toolName: toolName,
    activeStatus: "1",
    toolID: toolID,
    tlLifeHrs: tlLifeHrs,
    currTlLife: "0",
    description: description,
  };
  const tool = await query.addTool(toolDetails);
  res.redirect(`/plant/toolList?id=${id}`);
});

//==== Tool Reg End

//==== Reciepe Reg Start
routerPlant.get("/recipeRegistration", async function (req, res) {
  const id = req.query.id;
  const user = await query.fetchUserID(id);
  const users = await query.fetchAllUsers();
  const products = await query.fetchProduct(
    user.companyId,
    user._id.toString()
  );
  const tools = await query.fetchTools(user.companyId, user._id.toString());
  res.render(`Plant/recipeLibrary`, {
    users: users,
    user: user,
    id: user.companyId,
    plantId: user._id,
    products: products,
    tools: tools,
  });
});

routerPlant.post("/productRegistration", async function (req, res) {
  const id = req.query.id;
  const productDetails = req.body;

  try {
    const checkAdd = await query.productAdd(productDetails);

    if (checkAdd) {
      res.redirect(`/plant/recipeRegistration?id=${id}`);
    } else {
      res.redirect(`../*?error=404&error_desc=Product not added`);
    }
  } catch (error) {
    console.error("Error adding Product:", error);
    res
      .status(500)
      .json({ message: "Internal Server Error", error: error.message });
  }
});

routerPlant.post("/recipeRegistration", async function (req, res) {
  const id = req.query.id;
  const recipeDetails = req.body;

  try {
    const checkAdd = await query.recipeAdd(recipeDetails);

    if (checkAdd) {
      res.redirect(`/plant/recipeList?id=${id}`);
    } else {
      res.redirect(`../*?error=404&error_desc=Recipe not added`);
    }
  } catch (error) {
    console.error("Error adding Recipe:", error);
    res
      .status(500)
      .json({ message: "Internal Server Error", error: error.message });
  }
});

//==== Reciepe Reg End
//==== Reciepe List Start

routerPlant.get("/recipeList", async function (req, res) {
  console.log("Recipe List");
  const id = req.query.id;
  const user = await query.fetchUserID(id);
  const users = await query.fetchAllUsers();
  const products = await query.fetchProduct(
    user.companyId,
    user._id.toString()
  );
  const recipes = await query.fetchRecipes(user.companyId, user._id.toString());
  const tools = await query.fetchTools(user.companyId, user._id.toString());
  // Replace the productName in recipes with the actual productName if it matches the product._id
  recipes.forEach((recipe) => {
    const matchingProduct = products.find(
      (product) => product._id.toString() === recipe.productName
    );
    if (matchingProduct) {
      recipe.productName = matchingProduct.productName;
    }

    const matchingTool = tools.find(
      (tool) => tool._id.toString() === recipe.toolName
    );
    if (matchingTool) {
      recipe.toolName = matchingTool.toolName;
    }
  });

  console.log(recipes);
  res.render(`Plant/recipeList`, {
    users: users,
    user: user,
    id: user.companyId,
    recipes: recipes,
    products: products,
    tools: tools,
    plantId: user._id,
  });
});

routerPlant.get("/deleteRecipe", async function (req, res) {
  const deleteId = req.query.id;
  //   console.log("deleteId ==== ", deleteId);
  try {
    const checkDelete = await query.deleteRecipe(deleteId);

    if (checkDelete && checkDelete.deletedCount > 0) {
      res.status(200).json({ message: "Success", deletedId: deleteId });
    } else {
      res.status(404).json({ message: "Recipe not found or already deleted" });
    }
  } catch (error) {
    console.error("Error deleting Recipe:", error);
    res
      .status(500)
      .json({ message: "Internal Server Error", error: error.message });
  }
});

routerPlant.get("/deleteProduct", async function (req, res) {
  const deleteId = req.query.id;
  //   console.log("deleteId ==== ", deleteId);
  try {
    const checkDelete = await query.deleteProduct(deleteId);

    if (checkDelete && checkDelete.deletedCount > 0) {
      res.status(200).json({ message: "Success", deletedId: deleteId });
    } else {
      res.status(404).json({ message: "Product not found or already deleted" });
    }
  } catch (error) {
    console.error("Error deleting Product:", error);
    res
      .status(500)
      .json({ message: "Internal Server Error", error: error.message });
  }
});

routerPlant.post("/editRecipe", async function (req, res) {
  const id = req.query.id;
  const recipe = req.body;
  try {
    const checkEdit = await query.editRecipe(recipe.id, recipe);

    if (checkEdit) {
      res.redirect(`/plant/recipeList?id=${id}`);
    } else {
      res.redirect(
        `../*?error=404&error_desc=Recipe not found or already edited`
      );
    }
  } catch (error) {
    console.error("Error editing Recipe:", error);
    res
      .status(500)
      .json({ message: "Internal Server Error", error: error.message });
  }
});
//==== Reciepe List End
//==== Shift List Start
routerPlant.get("/shiftList", async function (req, res) {
  const id = req.query.id;
  const user = await query.fetchUserID(id);
  const users = await query.fetchAllUsers();
  const shifts = await query.fetchShift(user.companyId, user._id.toString());
  const breaks = await query.fetchBreak(user.companyId, user._id.toString());
  res.render(`Plant/shiftList`, {
    users: users,
    shifts: shifts,
    breaks: breaks,
    user: user,
    id: user.companyId,
    plantId: user._id,
  });
});

routerPlant.get("/deleteShiftBreak", async function (req, res) {
  const deleteId = req.query.id;
  try {
    const checkDelete = await query.deleteShiftBreak(deleteId);

    if (checkDelete && checkDelete.deletedCount > 0) {
      res.status(200).json({ message: "Success", deletedId: deleteId });
    } else {
      res.status(404).json({ message: "Shift not found or already deleted" });
    }
  } catch (error) {
    console.error("Error deleting Shift:", error);
    res
      .status(500)
      .json({ message: "Internal Server Error", error: error.message });
  }
});

routerPlant.post("/editShift", async function (req, res) {
  const id = req.query.id;
  const userDetails = req.body;

  try {
    const checkEdit = await query.editShift(userDetails.id, userDetails);

    if (checkEdit) {
      res.redirect(`/plant/shiftList?id=${id}`);
    } else {
      res.redirect(
        `../*?error=404&error_desc=Shift not found or already edited`
      );
    }
  } catch (error) {
    console.error("Error editing Shift:", error);
    res
      .status(500)
      .json({ message: "Internal Server Error", error: error.message });
  }
});

routerPlant.post("/editBreak", async function (req, res) {
  console.log("Edit Break");
  const id = req.query.id;
  const userDetails = req.body;
  console.log(userDetails);

  try {
    const checkEdit = await query.editBreak(userDetails.id2, userDetails);

    if (checkEdit) {
      res.redirect(`/plant/shiftList?id=${id}`);
    } else {
      res.redirect(
        `../*?error=404&error_desc=Break not found or already edited`
      );
    }
  } catch (error) {
    console.error("Error editing Break:", error);
    res
      .status(500)
      .json({ message: "Internal Server Error", error: error.message });
  }
});

//==== Shift List End

routerPlant.get("/shiftRegistration", async function (req, res) {
  const id = req.query.id;
  const user = await query.fetchUserID(id);
  const users = await query.fetchAllUsers();
  res.render(`Plant/shiftSetting`, {
    users: users,
    user: user,
    id: user.companyId,
    plantId: user._id,
  });
});

routerPlant.post("/shiftSetting", async function (req, res) {
  const id = req.query.id;
  const user = await query.fetchUserID(id);
  const { shiftName, shiftFrom, companyId, plantId, shiftTo } = req.body;
  const shiftDetails = {
    companyId: companyId,
    plantId: plantId,
    shiftName: shiftName,
    shiftFrom: shiftFrom,
    shiftTo: shiftTo,
    type: "1",
  };
  const users = await query.shiftAdd(shiftDetails);
  res.redirect(`/plant/shiftList?id=${id}`);
});

routerPlant.post("/breakSetting", async function (req, res) {
  const id = req.query.id;
  const user = await query.fetchUserID(id);
  const { breakName, breakFrom, breakTo, companyId, plantId } = req.body;
  const breakDetails = {
    companyId: companyId,
    plantId: plantId,
    breakName: breakName,
    breakFrom: breakFrom,
    breakTo: breakTo,
    type: "2",
  };
  const users = await query.breakAdd(breakDetails);
  res.redirect(`/plant/shiftList?id=${id}`);
});

routerPlant.get("/deviceRegistration", async function (req, res) {
  const id = req.query.id;
  const user = await query.fetchUserID(id);
  const users = await query.fetchAllUsers();
  const models = await query.fetchAllModels();
  res.render(`Plant/deviceRegistration`, {
    users: users,
    user: user,
    id: user.companyId,
    plantId: user._id,
    models: models,
  });
});

routerPlant.post("/deviceRegistration", async function (req, res) {
  const id = req.query.id;
  const user = await query.fetchUserID(id);
  console.log("Device Registration", req.body);
  const device = req.body;
  const deviceCheck = await query.deviceAdd(device);
  res.redirect(`/plant/deviceList?id=${id}`);
});

routerPlant.get("/deviceList", async function (req, res) {
  const id = req.query.id;
  const user = await query.fetchUserID(id);
  const users = await query.fetchAllUsers();
  const devices = await query.fetchDevices(user.companyId, user._id.toString());
  const models = await query.fetchAllModels();

  // Create a mapping from modelId to modelName
  const modelMap = models.reduce((acc, model) => {
    acc[model._id.toString()] = model.modelName;
    return acc;
  }, {});

  // Replace modelId with modelName in devices
  const updatedDevices = devices.map((device) => {
    return {
      ...device,
      model: modelMap[device.model] || device.model,
    };
  });

  console.log("Data:", updatedDevices);

  res.render(`Plant/deviceList`, {
    users: users,
    user: user,
    id: user.companyId,
    plantId: user._id,
    devices: updatedDevices,
    models: models,
  });
});

routerPlant.post("/editDevice", async function (req, res) {
  console.log("Edit Device");
  const id = req.query.id;
  const deviceDetails = req.body;

  try {
    const checkEdit = await query.editDevice(deviceDetails.id, deviceDetails);

    if (checkEdit) {
      res.redirect(`/plant/deviceList?id=${id}`);
    } else {
      res.redirect(
        `../*?error=404&error_desc=Device not found or already edited`
      );
    }
  } catch (error) {
    console.error("Error editing Device Info:", error);
    res
      .status(500)
      .json({ message: "Internal Server Error", error: error.message });
  }
});

routerPlant.get("/deleteDevice", async function (req, res) {
  const deleteId = req.query.id;
  console.log(deleteId);
  try {
    const checkDelete = await query.deleteDevice(deleteId);

    if (checkDelete && checkDelete.deletedCount > 0) {
      res.status(200).json({ message: "Success", deletedId: deleteId });
    } else {
      res.status(404).json({ message: "Device not found or already deleted" });
    }
  } catch (error) {
    console.error("Error deleting Device:", error);
    res
      .status(500)
      .json({ message: "Internal Server Error", error: error.message });
  }
});

routerPlant.get("/enableDevice", async function (req, res) {
  const enableId = req.query.id;
  const state = req.query.state;
  console.log("State:", state);
  try {
    const checkDelete = await query.enableDevice(enableId, state);

    if (checkDelete && checkDelete.deletedCount > 0) {
      res.status(200).json({ message: "Success", deletedId: enableId });
    } else {
      res.status(404).json({ message: "Device not found or already deleted" });
    }
  } catch (error) {
    console.error("Error enabling Device:", error);
    res
      .status(500)
      .json({ message: "Internal Server Error", error: error.message });
  }
  //res.send("OK");
});

routerPlant.get("/lineAllocation", async function (req, res) {
  const id = req.query.id;
  const user = await query.fetchUserID(id);
  const users = await query.fetchAllUsers();
  const lines = await query.fetchAllLines(user.companyId, user._id.toString());
  const products = await query.fetchProduct(
    user.companyId,
    user._id.toString()
  );

  const devices = await query.fetchDevices(user.companyId, user._id.toString());
  const allocatedLines = await query.fetchAllocatedLines(
    user.companyId,
    user._id.toString()
  );

  const tools = await query.fetchTools(user.companyId, user._id.toString());

  let unallocatedDevices = devices;

  if (allocatedLines && allocatedLines.length > 0) {
    const allocatedDeviceIds = allocatedLines.reduce((acc, line) => {
      return acc.concat(line.deviceId);
    }, []);

    unallocatedDevices = devices.filter(
      (device) => !allocatedDeviceIds.includes(device._id.toString())
    );
  }

  //console.log("available",unallocatedDevices);

  res.render(`Plant/lineAllocation`, {
    users: users,
    user: user,
    id: user.companyId,
    plantId: user._id,
    products: products,
    tools: tools,
    lines: lines,
    devices: unallocatedDevices,
  });
});

routerPlant.post("/lineAllocation", async function (req, res) {
  const id = req.query.id;
  const { plantId, companyId, lineId, deviceId, lineID } = req.body;
  var lineDetails;

  if (Array.isArray(deviceId)) {
    lineDetails = {
      plantId: plantId,
      companyId: companyId,
      lineId: lineId,
      lineID: lineID,
      deviceId: deviceId,
    };
  } else {
    lineDetails = {
      plantId: plantId,
      companyId: companyId,
      lineId: lineId,
      lineID: lineID,
      deviceId: [deviceId],
    };
  }

  try {
    const checkAdd = await query.lineAllocation(lineDetails);

    if (checkAdd) {
      res.redirect(`/plant/lineList?id=${id}`);
    } else {
      res.redirect(`../*?error=404&error_desc=Line not added`);
    }
  } catch (error) {
    console.error("Error adding Line:", error);
    res
      .status(500)
      .json({ message: "Internal Server Error", error: error.message });
  }
});

routerPlant.post("/lineRegistration", async function (req, res) {
  const id = req.query.id;
  const lineDetails = req.body;

  try {
    const checkAdd = await query.lineAdd(lineDetails);

    if (checkAdd) {
      res.redirect(`/plant/lineAllocation?id=${id}`);
    } else {
      res.redirect(`../*?error=404&error_desc=Line not added`);
    }
  } catch (error) {
    console.error("Error adding Line:", error);
    res
      .status(500)
      .json({ message: "Internal Server Error", error: error.message });
  }
});

routerPlant.get("/lineList", async function (req, res) {
  const id = req.query.id;
  const user = await query.fetchUserID(id);
  const users = await query.fetchAllUsers();
  const products = await query.fetchProduct(
    user.companyId,
    user._id.toString()
  );
  const recipes = await query.fetchRecipes(user.companyId, user._id.toString());
  const tools = await query.fetchTools(user.companyId, user._id.toString());

  const lines = await query.fetchAllLines(user.companyId, user._id.toString());
  console.log("Matching Line:", lines);
  const allocatedLines = await query.fetchAllocatedLines(
    user.companyId,
    user._id.toString()
  );
  const devices = await query.fetchDevices(user.companyId, user._id.toString());

  // If no devices are found, pass an error message
  let errorMessage = "";
  if (!devices || devices.length === 0) {
    errorMessage =
      "No devices found! Do you want to continue without devices or add a device to the line?";
  }

  let unallocatedDevices;
  const deviceMap = devices.reduce((map, device) => {
    map[device._id.toString()] = device.deviceName;
    return map;
  }, {});

  const deviceMap2 = devices.reduce((map, device) => {
    map[device._id.toString()] = device.deviceId;
    return map;
  }, {});

  const allocatedLinesWithDetails = allocatedLines.map((line) => {
    const matchingLine = lines.find((l) => l.lineId.toString() === line.lineId);
    const lineName = matchingLine.lineName;

    const deviceNames = line.deviceId.map(
      (deviceId) => deviceMap[deviceId] || "Unknown"
    );
    const deviceTemp = line.deviceId.map(
      (deviceId) => deviceMap2[deviceId] || "Unknown"
    );

    unallocatedDevices = devices;

    if (allocatedLines && allocatedLines.length > 0) {
      const allocatedDeviceIds = allocatedLines.reduce((acc, line) => {
        return acc.concat(line.deviceId);
      }, []);

      unallocatedDevices = devices.filter(
        (device) => !allocatedDeviceIds.includes(device._id.toString())
      );
    }

    return {
      ...line,
      deviceName: deviceNames,
      lineName: lineName,
      deviceId: deviceTemp,
    };
  });

  res.render("Plant/lineList", {
    users: users,
    user: user,
    lines: lines,
    allocatedLines: allocatedLinesWithDetails,
    id: user.companyId,
    recipes: recipes,
    products: products,
    tools: tools,
    plantId: user._id,
    devices: devices,
    unallocatedDevices: unallocatedDevices,
    errorMessage: errorMessage, // Pass the error message to frontend
  });
});

routerPlant.get("/deleteLine", async function (req, res) {
  const deleteId = req.query.id;
  //   console.log("deleteId ==== ", deleteId);
  try {
    const checkDelete = await query.deleteLine(deleteId);

    if (checkDelete && checkDelete.deletedCount > 0) {
      res.status(200).json({ message: "Success", deletedId: deleteId });
    } else {
      res.status(404).json({ message: "Product not found or already deleted" });
    }
  } catch (error) {
    console.error("Error deleting Product:", error);
    res
      .status(500)
      .json({ message: "Internal Server Error", error: error.message });
  }
});

routerPlant.get("/deleteAllocatedLine", async function (req, res) {
  const deleteId = req.query.id;
  const indexId = req.query.index;
  try {
    const checkDelete = await query.deleteLineDevice(deleteId, indexId);

    if (checkDelete && checkDelete.modifiedCount > 0) {
      res.status(200).json({ message: "Success", deletedId: deleteId });
    } else {
      res
        .status(404)
        .json({ message: "Device not found in Line or already deleted" });
    }
  } catch (error) {
    console.error("Error deleting Device from Line:", error);
    res
      .status(500)
      .json({ message: "Internal Server Error", error: error.message });
  }
});

routerPlant.post("/editAllocatedLine", async function (req, res) {
  console.log("Edit Allocated Lines");
  const id = req.query.id;
  const LineDetails = req.body;

  const devices = await query.fetchDeviceById(LineDetails.preDeviceId);
  try {
    const index = await query.getDeviceIdArrayIndex(
      LineDetails.id,
      devices._id
    );

    const result = await query.updateDeviceInLine(
      LineDetails.id,
      devices._id,
      LineDetails.editDeviceId,
      index
    );
    if (result) {
      res.redirect(`/plant/lineList?id=${id}`);
    } else {
      res.redirect(
        `../*?error=404&error_desc=Device not found or already edited`
      );
    }
  } catch (error) {
    console.error("Error editing Device Info:", error);
    res
      .status(500)
      .json({ message: "Internal Server Error", error: error.message });
  }
});

routerPlant.post("/editLine", async function (req, res) {
  const deleteId = req.query.id;
  const LineDetails = req.body;
  const id = req.query.id;
  try {
    const devices = await query.editLineMain(
      LineDetails.LineIdGot,
      LineDetails.LineIdEdit,
      LineDetails.LineNameEdit
    );
    const Line = await query.fetchAllocatedLineById(LineDetails.LineIdGot);
    const devices2 = await query.editLineAllocation(
      Line._id,
      LineDetails.LineIdEdit
    );
    if (devices2) {
      res.redirect(`/plant/lineList?id=${id}`);
    } else {
      res.redirect(
        `../*?error=404&error_desc=Device not found or already edited`
      );
    }
  } catch (error) {
    console.error("Error editing Device Info:", error);
    res
      .status(500)
      .json({ message: "Internal Server Error", error: error.message });
  }
});

routerPlant.get("/dailyPlanning", async function (req, res) {
  const id = req.query.id;
  const user = await query.fetchUserID(id);
  const users = await query.fetchAllUsers();
  const lines = await query.fetchAllLines(user.companyId, user._id.toString());
  const products = await query.fetchProduct(
    user.companyId,
    user._id.toString()
  );
  const shifts = await query.fetchShift(user.companyId, user._id.toString());
  const breaks = await query.fetchBreak(user.companyId, user._id.toString());
  const devices = await query.fetchDevices(user.companyId, user._id.toString());
  const allocatedLines = await query.fetchAllocatedLines(
    user.companyId,
    user._id.toString()
  );
  const recipes = await query.fetchRecipes(user.companyId, user._id.toString());
  const DateTime = await Func.getCurrentDateTime();
  console.log("Date:", DateTime);
  // console.log("devices === ", devices);

  const tools = await query.fetchTools(user.companyId, user._id.toString());

  res.render(`Plant/dailyPlanning`, {
    users: users,
    user: user,
    id: user.companyId,
    plantId: user._id,
    products: products,
    shifts: shifts,
    breaks: breaks,
    tools: tools,
    lines: lines,
    devices: devices,
    allocatedLines: allocatedLines,
    recipes: recipes,
    DateTime: DateTime,
  });
});

routerPlant.post("/dailyPlanning", async function (req, res) {
  const id = req.query.id;
  const Details = req.body;

  try {
    const checkAdd = await query.dailyPlanning(Details);

    if (checkAdd) {
      res.redirect(`/plant/todaysPlanning?id=${id}`);
    } else {
      res.redirect(`../*?error=404&error_desc= not added`);
    }
  } catch (error) {
    console.error("Error adding:", error);
    res
      .status(500)
      .json({ message: "Internal Server Error", error: error.message });
  }
});

routerPlant.get("/todaysPlanning", async function (req, res) {
  try {
    console.log("Request received at /todaysPlanning");

    const id = req.query.id;
    console.log("Query parameter ID:", id);

    const user = await query.fetchUserID(id);
    console.log("Fetched user:", user);

    const users = await query.fetchAllUsers();
    console.log("Fetched all users count:", users.length);

    const DateTime = await Func.getCurrentDateTime();
    console.log("Current DateTime:", DateTime);

    const planning = await query.fetchPlanningByDate(
      user.companyId,
      user._id.toString(),
      DateTime.date
    );
    console.log("Planning data fetched:", planning);

    const Finalplanning = await query.fetchFinalPlanning(
      user.companyId,
      user._id.toString(),
      DateTime.date
    );
    console.log("Final planning data fetched:", Finalplanning);

    const enrichedPlanning = [];
    const basicPlanning = [];

    for (const plan of planning) {
      console.log("Processing plan:", plan);

      const recipes = await query.fetchRecipeByProductName(
        user.companyId,
        user._id.toString(),
        plan.product
      );
      console.log("Fetched recipes for product:", plan.product, recipes);

      const productDetails = await query.fetchProductById(plan.product);
      console.log("Fetched product details:", productDetails);

      const devicesPreLine = await query.fetchDevicesInLine(plan.line);
      console.log("Devices in line:", devicesPreLine);

      const lineDetails = await query.fetchDataInLine(plan.line);
      console.log("Line details fetched:", lineDetails);

      const shiftDetails = await query.fetchShiftById(plan.shift);
      console.log("Shift details fetched:", shiftDetails);

      const deviceDetails = [];
      for (const device of devicesPreLine) {
        const deviceDetail = await query.fetchDeviceByObjId(device);
        console.log("Fetched device detail:", deviceDetail);
        deviceDetails.push(deviceDetail);
      }

      const enrichedRecipes = [];
      for (const recipe of recipes) {
        const toolDetails = await query.findToolByObjId(recipe.toolName);
        console.log("Fetched tool details for recipe:", recipe, toolDetails);

        enrichedRecipes.push({
          ...recipe,
          toolDetails: toolDetails,
          productDetails: productDetails,
        });
      }

      basicPlanning.push({
        ...plan,
        lineDetails: lineDetails,
        productDetails: productDetails,
        shiftDetails: shiftDetails,
      });

      enrichedPlanning.push({
        ...plan,
        lineDetails: lineDetails,
        devices: deviceDetails,
        recipes: enrichedRecipes,
        shiftDetails: shiftDetails,
      });
    }

    console.log(
      "Final Enriched Planning Data:",
      util.inspect(enrichedPlanning, { depth: null, colors: true })
    );

    res.render("Plant/todaysPlanning", {
      users: users,
      user: user,
      id: user.companyId,
      plantId: user._id,
      DateTime: DateTime,
      planning: enrichedPlanning,
      basicPlanning: basicPlanning,
    });
  } catch (error) {
    console.error("Error in /todaysPlanning route:", error);
    res.status(500).send("Internal Server Error");
  }
});

routerPlant.get("/planning", async function (req, res) {
  const id = req.query.id;
  const user = await query.fetchUserID(id);
  const users = await query.fetchAllUsers();
  const DateTime = req.query.DateTime;
  console.log("DateTime", DateTime);
  const planning = await query.fetchPlanningByDate(
    user.companyId,
    user._id.toString(),
    DateTime
  );
  //console.log(planning);

  // Array to hold enriched planning details
  const enrichedPlanning = [];
  const basicPlanning = [];

  for (const plan of planning) {
    const recipes = await query.fetchRecipeByProductName(
      user.companyId,
      user._id.toString(),
      plan.product
    );
    //console.log("recipe === ", recipes);
    const productDetails = await query.fetchProductById(plan.product);
    const devicesPreLine = await query.fetchDevicesInLine(plan.line);
    const lineDetails = await query.fetchDataInLine(plan.line);
    const shiftDetails = await query.fetchShiftById(plan.shift);
    //console.log("devices ===", devicesPreLine);

    // Fetch device details
    const deviceDetails = [];
    for (const device of devicesPreLine) {
      const deviceDetail = await query.fetchDeviceByObjId(device);
      //console.log("Device Details:", deviceDetail);
      deviceDetails.push(deviceDetail);
    }

    // Enrich each recipe with tool and product details
    const enrichedRecipes = [];
    for (const recipe of recipes) {
      const toolDetails = await query.findToolByObjId(recipe.toolName);
      //console.log("tool details", toolDetails);
      // const productDetails = await query.fetchProductById(recipe._id);
      //console.log("product details", productDetails);

      enrichedRecipes.push({
        ...recipe,
        toolDetails: toolDetails,
        productDetails: productDetails,
      });
    }

    // Enrich the plan with device details, line details, and enriched recipes
    basicPlanning.push({
      ...plan,
      lineDetails: lineDetails,
      productDetails: productDetails,
      shiftDetails: shiftDetails,
    });
    enrichedPlanning.push({
      ...plan,
      lineDetails: lineDetails,
      devices: deviceDetails,
      recipes: enrichedRecipes,
      shiftDetails: shiftDetails,
    });
  }

  // console.log("Merged Planning Data:", util.inspect(enrichedPlanning, { depth: null, colors: true }));
  // console.log("Basic Planning Data:", util.inspect(basicPlanning, { depth: null, colors: true }));
  console.log("Planning:", DateTime);
  res.json({ planning: enrichedPlanning, basicPlanning: basicPlanning });
});

routerPlant.get("/deleteTodayPlanning", async function (req, res) {
  const deleteId = req.query.id;

  try {
    const checkDelete = await query.deleteTodayPlanning(deleteId);

    if (checkDelete && checkDelete.deletedCount > 0) {
      res.status(200).json({ message: "Success", deletedId: deleteId });
    } else {
      res.status(404).json({
        message: "Today's planning not found in Line or already deleted",
      });
    }
  } catch (error) {
    console.error("Error deleting Todays Planning:", error);
    res
      .status(500)
      .json({ message: "Internal Server Error", error: error.message });
  }
});

routerPlant.post("/saveTodayData", async function (req, res) {
  const tableData = req.body;
  const id = req.query.id;
  console.log("Table Data:", tableData);

  const {
    deviceId,
    shiftId,
    activeProcess,
    operatingActual,
    productionActual,
  } = tableData;

  // Step 1: Process activeProcess based on deviceId and shiftId
  const deviceShiftMap = new Map();

  deviceId.forEach((device, index) => {
    const key = `${device}_${shiftId[index]}`;
    if (!deviceShiftMap.has(key)) {
      deviceShiftMap.set(key, []);
    }
    deviceShiftMap.get(key).push(index);
  });

  deviceShiftMap.forEach((indices) => {
    if (indices.length > 1) {
      // Multiple devices found with the same deviceId and shiftId
      activeProcess[indices[0]] = "1";
      for (let i = 1; i < indices.length; i++) {
        activeProcess[indices[i]] = "0";
      }
    } else {
      // Only one device found
      activeProcess[indices[0]] = "1";
    }
  });

  // Step 2: Update OperatingHours and productionActual to 0 if they are blank
  tableData.operatingActual = operatingActual.map((hour) =>
    hour === "" ? "0" : hour
  );
  tableData.productionActual = productionActual.map((actual) =>
    actual === "" ? "0" : actual
  );

  // Process and save the table data as needed
  try {
    const checkAdd = await query.PlanningPerDeviceRecipeLine(tableData);

    if (checkAdd) {
      res.redirect(`/plant/todaysPlanning?id=${id}`);
    } else {
      res.redirect(`../*?error=404&error_desc= not added`);
    }
  } catch (error) {
    console.error("Error adding Final Planning:", error);
    res
      .status(500)
      .json({ message: "Internal Server Error", error: error.message });
  }
});

routerPlant.post("/startTime", async (req, res) => {
  const id = req.query.id; // Extract query parameter
  const startDetails = req.body; // Extract request body

  try {
    console.log(
      "================================== CALLED =================================="
    );
    console.log("BODY =", startDetails);

    // Validate request body
    if (!startDetails.deviceId || !startDetails.status || !startDetails.time) {
      return res
        .status(400)
        .json({ success: false, message: "Missing required fields" });
    }

    // Assuming `query.startProcess` is a function that processes start time
    const processStart = await query.startProcess(startDetails);

    if (processStart) {
      res.redirect(`/plant/startConfirmation?id=${id}`);
    } else {
      res.redirect(`../*?error=500&error_desc=Start process failed`);
    }
  } catch (error) {
    console.error("Error processing startTime:", error);
    res
      .status(500)
      .json({ message: "Internal Server Error", error: error.message });
  }
});

// Add more admin routes here
module.exports = routerPlant;
