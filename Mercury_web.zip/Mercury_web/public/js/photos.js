    // Function to handle file selection
    document.getElementById('uploadInput').addEventListener('change', function(event) {
        const file = event.target.files[0];
        if (file) {
            // Perform actions with the selected file, e.g., display preview, upload to server, etc.
            // For example, displaying a preview of the selected image:
            const reader = new FileReader();
            reader.onloadend = function() {
                document.getElementById('profileImage').src = reader.result;
            };
            reader.readAsDataURL(file);
        }
    });


         // Function to handle file selection
         document.getElementById('uploadLogoInput').addEventListener('change', function(event) {
            const file = event.target.files[0];
            if (file) {
                // Perform actions with the selected file, e.g., display preview, upload to server, etc.
                // For example, displaying a preview of the selected image:
                const reader = new FileReader();
                reader.onloadend = function() {
                    document.getElementById('logoImage').src = reader.result;
                };
                reader.readAsDataURL(file);
            }
        });