// [1] Imports
const express = require("express");
const dotenv = require("dotenv");
const bodyParser = require("body-parser");
const methodOverride = require("method-override");
const session = require("express-session");
const path = require("path");
const flash = require("connect-flash");
const passport = require("passport");
const LocalStrategy = require("passport-local").Strategy;
const MongoDBStore = require("connect-mongodb-session")(session);
const query = require("./dbQueries");
const Func = require("./functions");
const util = require("util");

// [INFO] Routes
const adminRoutes = require("./routes/admin/admin");
const companyRoutes = require("./routes/company/company");
const operatorRoutes = require("./routes/operator/operator");
const plantRoutes = require("./routes/plant/plant");
const supervisorRoutes = require("./routes/supervisor/supervisor");

const app = express();

// [INFO] Load the .env
dotenv.config();

// [INFO] Passport Config
passport.use(
  new LocalStrategy(
    {
      usernameField: "email",
      passwordField: "password",
    },
    async (email, password, done) => {
      try {
        const user = await query.fetchUserEmail(email);
        if (!user) {
          console.log("Incorrect email.");
          return done(null, false, { message: "Incorrect email." });
        }
        if (user.password !== password) {
          console.log("Incorrect password.");
          return done(null, false, { message: "Incorrect password." });
        }
        return done(null, user);
      } catch (err) {
        return done(err);
      }
    }
  )
);

passport.serializeUser((user, done) => {
  done(null, user._id.toString());
});

passport.deserializeUser(async (id, done) => {
  try {
    const user = await query.fetchUserID(id);
    done(null, user);
  } catch (err) {
    done(err);
  }
});

// [INFO] Express Configuration
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "/public/views"));

app.use(express.static(path.join(__dirname, "public")));
app.use(express.static(path.join(__dirname, "uploads")));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(methodOverride("_method"));

// Routes Used
app.use("/admin", adminRoutes);
app.use("/company", companyRoutes);
app.use("/operator", operatorRoutes);
app.use("/plant", plantRoutes);
app.use("/supervisor", supervisorRoutes);

// [INFO] Session setup
const store = new MongoDBStore({
  uri: "mongodb://0.0.0.0:27017/KVAR-CLOUD",
  collection: "sessions",
});

app.use(
  session({
    secret: "VISHAL",
    resave: true,
    saveUninitialized: true,
    store: store,
  })
);

app.use(passport.initialize());
app.use(passport.session());
app.use(flash());

// Global variables
app.use((req, res, next) => {
  res.locals.success_msg = req.flash("success_msg");
  res.locals.error_msg = req.flash("error_msg");
  res.locals.error = req.flash("error");
  next();
});

const PORT = process.env.PORT || 3001;

// Middleware to check if the user is logged in
function requireLogin(req, res, next) {
  if (req.isAuthenticated()) {
    return next();
  }
  req.flash("error_msg", "Please log in to view that resource");
  res.redirect("/");
}

// [INFO] Routes
app.get("/", (req, res) => {
  res.render("login", { message: req.flash("error") });
});

// Login form submission route
app.post("/login", (req, res, next) => {
  passport.authenticate("local", (err, user, info) => {
    if (err) {
      return next(err);
    }
    if (user) {
      req.logIn(user, (err) => {
        if (err) {
          return next(err);
        }
        if (user.type == "1") {
          console.log("Company Level : Login ");
          return res.redirect(`/company/dashboard?id=${user._id}`);
        } else if (user.type == "2") {
          console.log("Plant Level : Login ");
          return res.redirect(`/plant/dashboard?id=${user._id}`);
        } else if (user.type == "3") {
          console.log("Supervisor Level : Login ");
          return res.redirect(`/supervisor/dashboard?id=${user._id}`);
        } else if (user.type == "4") {
          console.log("Operator Level : Login ");
        }
      });
    } else if (
      req.body.email === "admin@kvar" &&
      req.body.password === "kvar"
    ) {
      req.session.isAdmin = true;
      return res.redirect("kvarDashboard");
    } else if (
      req.body.email === "admin@mercury" &&
      req.body.password === "mercury"
    ) {
      req.session.isAdmin = true;
      return res.redirect("/admin/dashboard");
    } else {
      req.flash("error_msg", "Invalid credentials. Please try again.");
      return res.redirect("/");
    }
  })(req, res, next);
});

app.get("/dashboard", (req, res) => {
  res.send("Welcome");
});

app.get("/forgetPassword", (req, res) => {
  res.render("forgetPwd");
});

app.post("/forgetPassword", async (req, res) => {
  const { email } = req.body;
  console.log(email);
  const password = Func.generateRandomPassword(8);
  const emailCheck1 = await Func.SendHtmlDefaultPwd(
    email,
    "Welcome to Production Genie !",
    email,
    password
  );
  const check = await query.updatePassword(email, password);
  res.redirect("/");
});

app.post("/changePassword", async (req, res) => {
  const { newPassword, id, backlink } = req.body;
  const check = await query.updatePasswordById(id, newPassword);
  res.redirect(backlink);
});

// Suoer Admin Page : KVAR
app.get("/kvarDashboard", (req, res) => {
  res.render("kvarDashboard");
});

// Test HTML OTP MAil
app.get("/testMail", async function (req, res) {
  const email = "kvartech.shoaibmulla@gmail.com";
  const emailCheck1 = await Func.SendHtmlOTP(email, "Your OTP", 123);
  res.send("Success");
});

// Generic OTP verification System
app.get("/otpVerify", async function (req, res) {
  const { otp, email, altEmail } = req.query;
  const emailCheck1 = await Func.SendHtmlOTP(email, "Your OTP", otp);
  if (altEmail) {
    const emailCheck2 = await Func.SendHtmlOTP(altEmail, "Your OTP", otp);
  }

  res.send("Success");
});

app.get("/modelSetting", async (req, res) => {
  const Models = await query.fetchAllModels();

  res.render("modelSetting", { Models: Models });
});

app.post("/modelAdd", async (req, res) => {
  console.log("Model Add", req.body);
  const Model = req.body;

  try {
    const checkModel = await query.addModel(Model);

    if (checkModel) {
      res.redirect("modelSetting");
    } else {
      res.redirect(`/*?error=404&error_desc=Model not added`);
    }
  } catch (error) {
    console.error("Error adding Model:", error);
    res
      .status(500)
      .json({ message: "Internal Server Error", error: error.message });
  }
});

app.post("/modelParms", async (req, res) => {
  console.log("Model Add", req.body);
  const Model = req.body;

  try {
    const checkModel = await query.addModelPara(Model);

    if (checkModel) {
      res.redirect("/ModelList");
    } else {
      res.redirect(`/*?error=404&error_desc=ModelPara not added`);
    }
  } catch (error) {
    console.error("Error adding ModelPara:", error);
    res
      .status(500)
      .json({ message: "Internal Server Error", error: error.message });
  }
});

app.get("/deviceData", async (req, res) => {
  const { Id, companyId,plantId,modelId, ...otherParams } = req.query;
  const deviceId = Id;
  console.log("Device Id:",deviceId);
  console.log("Company Id:",companyId);
  console.log("Plant Id:",plantId);
  console.log("Model Id:",modelId);

  // Fetch the model data based on modelId
  const model = await query.fetchModelParms(modelId);
  var responseData;
  const All_shift = await query.fetchShift(companyId,plantId);
  const DateTime = await Func.getCurrentDateTime();
  console.log("DateTime:",DateTime);console.log("Shift Data:",All_shift);
  const currentShift = await Func.getCurrentShift(DateTime, All_shift);
  console.log("Current Shift",currentShift);
 
  const finalPlanning = await query.fetchFinalPlanning(companyId,plantId,DateTime.date)
  if(finalPlanning.length <= 0){
    console.log("No Data Available"); 
  }else{
    //console.log("Final Planning:", finalPlanning);
    const deviceDetail = await query.fetchDeviceById(Id);
    //Chnage the cureent shift if device is not in that shift 
    const changeShift = await query.changeShift(companyId,plantId,DateTime.date,currentShift,deviceDetail._id.toString());
    //console.log("Device Details:", deviceDetail);
    const index = await Func.findDeviceIndex(deviceDetail._id.toString(),currentShift,finalPlanning);
    console.log("index:",index);
    const operatingHrs = await Func.getOperatingHrs(index,finalPlanning);
    const productionTarget = await Func.getProductionPlanning(index,finalPlanning);
    const runningProcess = await Func.getRuningProcessPlanning(index,finalPlanning);

    var currentTarget = 0;
    var currentOperatingHrs = 0;
    if (model) {
      const numberOfParameters = model.numberOfParameters;
      responseData = {
        deviceId:deviceDetail._id.toString(),
        companyId,
        date:DateTime.date,
        time:DateTime.time,
        plantId,
        currentShift,
        operatingHrs,
        productionTarget,
        currentTarget,
        currentOperatingHrs,
        runningProcess,
        parameters: [],
      };

      for (let i = 0; i < numberOfParameters; i++) {
        const parameterKey = model[`parameterKey${i}`];
        const parameterFormula = model[`parameterFormula${i}`];
        responseData.parameters.push({
          parameterKey,
          parameterFormula,
          value: otherParams[parameterKey] || "",
        });
      }
      const addDeviceData = await query.addDeviceData(responseData);
      console.log("ADD DEVICE DATA === ",addDeviceData);
      //console.log(responseData);
      const operatingActual = "0";
      const productionActual = "0";


      const appendFinalPlanning = await query.appendFinalPlanning(companyId,plantId,DateTime.date,index,responseData.parameters,operatingActual,productionActual);
    }
    // const change = {
    //   Clr:true
    // };
    // if(changeShift){

    //   res.status(200).send(change);
    // }
      //res.send("Ok");
    // }else{
    //   res.send("Ok");
    // }
    res.status(200).send("OK");
  }
});

const splitParameters = (modelParaArray) => {
  const result = [];

  modelParaArray.forEach(model => {
    const numberOfParameters = parseInt(model.numberOfParameters, 10);

    for (let i = 0; i < numberOfParameters; i++) {
      const parameterKey = model[`parameterKey${i}`];
      const parameterFormula = model[`parameterFormula${i}`];

      result.push({
        _id: model._id,
        modelId: model.modelId,
        modelName: model.modelName,
        parameterKey,
        parameterFormula,
      });
    }
  });

  return result;
};

app.get("/ModelList", async (req, res) => {
  const Models = await query.fetchAllModels();
  const ModelPara  = await query.fetchAllModelsParms();
    // Create a mapping from modelId to modelName
    const modelMap = Models.reduce((acc, model) => {
      acc[model._id.toString()] = model.modelName;
      return acc;
    }, {});

    // Replace modelId with modelName in ModelPara
    const updatedModelPara = ModelPara.map(para => {
      return {
        ...para,
        modelName: modelMap[para.modelId] || para.modelId // Replace modelId with modelName, if not found keep the original ID
      };
    });

    console.log("Models:", Models);
    console.log("Models:", updatedModelPara);
    const splitParams = splitParameters(updatedModelPara);
    console.log("Updated ModelPara:", splitParams);
  res.render("modelList",{models:splitParams});
});

app.get("/deleteModel", async (req, res) => {
  const deleteId = req.query;
  try {
    const checkDelete = await query.deleteModel(deleteId);

    if (checkDelete && checkDelete.deletedCount > 0) {
      res.status(200).json({ message: "Success", deletedId: deleteId });
    } else {
      res.status(404).json({ message: "Device not found or already deleted" });
    }
  } catch (error) {
    console.error("Error deleting Device:", error);
    res
      .status(500)
      .json({ message: "Internal Server Error", error: error.message });
  }

});

// All Logout route
app.get("/logout", (req, res) => {
  req.logout((err) => {
    if (err) {
      return next(err);
    }
    req.session.destroy((err) => {
      if (err) {
        return next(err);
      }
      res.redirect("/");
    });
  });
});

// Error Page
app.get("*", (req, res) => {
  const error = req.query.error || "404";
  const error_desc = req.query.error_desc || "Page not found";
  res.render("error", {
    error: error,
    error_desc: error_desc,
  });
});

app.listen(PORT, () => console.info(`App listening on port ${PORT}`));
