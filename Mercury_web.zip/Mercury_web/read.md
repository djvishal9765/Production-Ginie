Roles 
1: Company Login
2. Plant Login
3. Supervisor
4. Operator 
