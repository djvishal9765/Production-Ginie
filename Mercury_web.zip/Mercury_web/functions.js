const Handlebars = require("handlebars");
const { ObjectID } = require("mongodb");
nodemailer = require("nodemailer");

transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "sales.kvartech@gmail.com",
    pass: "rdkd ucia wxad dasd",
  },
});

module.exports = {
  generateRandomPassword: function generateRandomPassword(length) {
    var characters =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    var password = "";
    for (var i = 0; i < length; i++) {
      var randomIndex = Math.floor(Math.random() * characters.length);
      password += characters[randomIndex];
    }
    return password;
  },
  SendHtmlOTP: async function SendHtmlOTP(To, SUB, OTP) {
    try {
      // Correct the path to the OTP.html file
      const filePath = path.join(__dirname, "public", "views", "OTP.html");
      const content = fs.readFileSync(filePath, "utf-8"); // Read the email template

      const template = Handlebars.compile(content);
      const data = { OTP: OTP };
      const output = template(data);

      // Define mail options
      var mailOptions2 = {
        from: process.env.KVAR_FROM,
        to: To,
        subject: SUB,
        html: output,
      };

      // Send the email
      transporter.sendMail(mailOptions2, function (error, info) {
        if (error) {
          console.log(error);
        } else {
          console.log("Email sent: " + info.response);
        }
      });
    } catch (error) {
      console.log("Error in sending email:", error);
    }
  },

  //  Send OTP Function
  SendHtmlDefaultPwd: async function SendHtmlDefaultPwd(
    To,
    SUB,
    username,
    password
  ) {
    try {
      // Correct the path to the OTP.html file
      const filePath = path.join(
        __dirname,
        "public",
        "views",
        "defPassword.html"
      );
      const content = fs.readFileSync(filePath, "utf-8"); // Read the email template

      const template = Handlebars.compile(content);
      const data = { email: username, password: password };
      const output = template(data);

      // Define mail options
      var mailOptions2 = {
        from: process.env.KVAR_FROM,
        to: To,
        subject: SUB,
        html: output,
      };

      // Send the email
      transporter.sendMail(mailOptions2, function (error, info) {
        if (error) {
          console.log(error);
        } else {
          console.log("Email sent: " + info.response);
        }
      });
    } catch (error) {
      console.log("Error in sending email:", error);
    }
  },
  getCurrentDateTime: async function getCurrentDateTime() {
    const now = new Date();

    // Get current date in the format YYYY-MM-DD
    const currentDate = now.toISOString().split("T")[0];

    // Get current time in the format HH:MM:SS
    const currentTime = now.toTimeString().split(" ")[0];

    return {
      date: currentDate,
      time: currentTime,
    };
    function timeToMinutes(timeStr) {
      const [hours, minutes] = timeStr.split(":").map(Number);
      return hours * 60 + minutes;
    }
  },

 getCurrentShift: async function getCurrentShift(dateTime, shiftData) {
    console.log("Debug: Function getCurrentShift called");
    console.log("Current DateTime:", dateTime);
    console.log("Received shiftData:", JSON.stringify(shiftData, null, 2));

    // Convert time string to minutes since midnight
    function timeToMinutes(timeStr) {
        const [hours, minutes] = timeStr.split(":").map(Number);
        const totalMinutes = hours * 60 + minutes;
        console.log("Converting", timeStr, "to", totalMinutes, "minutes");
        return totalMinutes;
    }

    // Get current time in minutes since midnight
    const currentTimeMinutes = timeToMinutes(dateTime.time);
    console.log("Current Time in Minutes:", currentTimeMinutes);

    // Iterate through shifts to find the current one
    for (const shift of shiftData) {
        const shiftStartMinutes = timeToMinutes(shift.shiftFrom);
        const shiftEndMinutes = timeToMinutes(shift.shiftTo);

        console.log("Checking shift:", shift._id, "| From:", shift.shiftFrom, "(", shiftStartMinutes, "minutes )",
            "To:", shift.shiftTo, "(", shiftEndMinutes, "minutes )");

        // Handle shifts that go past midnight
        if (shiftStartMinutes <= currentTimeMinutes && currentTimeMinutes < shiftEndMinutes) {
            console.log("Match Found. Current Shift ID:", shift._id.toString());
            return shift._id.toString();
        }
    }

    console.log("No matching shift found");
    return null;
},

  findDeviceIndex:async function findDeviceIndex(deviceId, shiftId, finalPlanning) {
    const planning = finalPlanning[0]; // Accessing the first (and only) element of the array
    
    for (let i = 0; i < planning.deviceId.length; i++) {
      if (planning.deviceId[i] === deviceId && 
          planning.shiftId[i] === shiftId && 
          planning.activeProcess[i] === '1') {
        return i;
      }
    }
    
    return -1; // Return -1 if no matching index is found
  },
  getProductionPlanning : async function getProductionPlanning(index, finalPlanning) {
    const planning = finalPlanning[0]; // Accessing the first (and only) element of the array
    return planning.productionTarget[index];
  },
  getOperatingHrs: async function getOperatingHrs(index, finalPlanning) {
    const planning = finalPlanning[0]; // Accessing the first (and only) element of the array
    return planning.operatingHours[index];
  },
  getRuningProcessPlanning: async function getRuningProcessPlanning(index, finalPlanning) {
    const planning = finalPlanning[0]; // Accessing the first (and only) element of the array
    return planning.recipeId[index];
  }
};
