const dotenv = require("dotenv");
dotenv.config();
const { MongoClient, ObjectId } = require("mongodb");
const uri = process.env.DATABASE_URL;
// const client = new MongoClient(uri, {
//   useNewUrlParser: true,
//   useUnifiedTopology: true,
// });
let client = new MongoClient(uri);

async function testConnection() {
  try {
    await client.connect();
    console.log("Successfully connected to MongoDB");
    return true;
  } catch (e) {
    console.error("Failed to connect to MongoDB", e);
    return false;
  } finally {
    await client.close();
  }
}

module.exports = {
  testConnection,
  fetchUserID: async function fetchUserID(id) {
    var result = null;

    try {
      await client.connect();
      result = await client
        .db("KVAR-CLOUD")
        .collection("registers")
        .findOne({ _id: new ObjectId(id) });
    } catch (e) {
      console.log("Error fetching user by ID:", e);

      if (
        e.name === "MongoTopologyClosedError" ||
        e.name === "MongoPoolClosedError"
      ) {
        console.log("Reconnecting to database...");
        client = new MongoClient(process.env.DATABASE_URL); // Reinitialize client
        return await fetchUserID(id); // Retry
      }

      result = null;
    } finally {
      await client.close();
      return result;
    }
  },
  fetchUserEmail: async function fetchUserEmail(email) {
    var result = null;

    try {
      await client.connect();
      result = await client
        .db("KVAR-CLOUD")
        .collection("registers")
        .findOne({ email: email });
    } catch (e) {
      console.log("Error fetching user by email:", e);
      result = null;
    } finally {
      await client.close();
      return result;
    }
  },
  fetchUserEmail: async function fetchUserEmail(email) {
    var result = null;

    try {
      await client.connect();
      result = await client
        .db("KVAR-CLOUD")
        .collection("registers")
        .findOne({ email: email });
    } catch (e) {
      console.log("Error fetching user by email:", e);
      result = null;
    } finally {
      await client.close();
      return result;
    }
  },
  addReportData: async function addReportData(
    currentShift,

    companyId,
    plantId,

    deviceId,
    date,
    parameters,
    operatingActual,
    productionActual
  ) {
    try {
      console.log("Connecting to the database");
      await client.connect();

      const todayStart = new Date(date);
      todayStart.setHours(0, 0, 0, 0);

      const operatingActualInt = parseInt(operatingActual, 10) || 0;
      const productionActualInt = parseInt(productionActual, 10) || 0;

      console.log("Checking if an existing report exists");
      const existingReport = await client
        .db("KVAR-CLOUD")
        .collection("ReportData")
        .findOne({
          companyId: companyId,
          plantId: plantId,
          deviceId: deviceId,
          currentShift: currentShift,
          date: todayStart,
        });

      if (existingReport) {
        console.log("Updating existing report");
        const updatedData = {
          $set: {
            updatedAt: new Date(),
            parameters: parameters || [], 
          },
          $inc: {
            operatingActual: operatingActualInt,
            productionActual: productionActualInt,
          },
        };

        const updateResult = await client
          .db("KVAR-CLOUD")
          .collection("ReportData")
          .updateOne({ _id: existingReport._id }, updatedData);

        console.log("Existing report updated", updateResult.modifiedCount);
        return existingReport._id;
      } else {
        console.log("Creating new report");
        const reportData = {
          companyId: companyId,
          plantId: plantId,
          currentShift: currentShift,
          deviceId: deviceId,
          date: todayStart,
          parameters: parameters || [],
          operatingActual: operatingActualInt,
          productionActual: productionActualInt,
          createdAt: new Date(),
          updatedAt: new Date(),
        };

        const result = await client
          .db("KVAR-CLOUD")
          .collection("ReportData")
          .insertOne(reportData);

        console.log("New report data added", result.insertedId);
        return result.insertedId;
      }
    } catch (e) {
      console.error("Error adding/updating report data", e.message);
      return null;
    } finally {
      console.log("Closing database connection");
      await client.close();
    }
  },

  // fetchReportData: async function fetchReportData(companyId, plantId, shiftId, deviceId, userId) {
  //     try {
  //         console.log("Connecting to the database");
  //         await client.connect();

  //         console.log("Fetching data with the following parameters");
  //         console.log("Company ID:", companyId);
  //         console.log("Plant ID:", plantId);
  //         console.log("Shift ID:", shiftId);
  //         console.log("Device ID:", deviceId);
  //         console.log("User ID:", userId);

  //         const result = await client
  //             .db("KVAR-CLOUD")
  //             .collection("ReportData")
  //             .find({
  //                 companyId: companyId,
  //                 plantId: plantId,
  //                 shiftId: shiftId,
  //                 deviceId: deviceId,
  //                 userId: userId
  //             })
  //             .toArray();

  //         console.log("Fetched data from the database");
  //         console.log(result);

  //         return result;
  //     } catch (e) {
  //         console.log("An error occurred while fetching data");
  //         console.log(e.message);
  //         return null;
  //     } finally {
  //         console.log("Closing the database connection");
  //         await client.close();
  //     }
  // },

  fetchReportData: async function fetchReportData() {
    var result = null;
    var cursor = null;
    try {
      // console.log("Connecting to MongoDB...");
      await client.connect();

      // console.log("Fetching data from reportData collection...");
      cursor = await client.db("KVAR-CLOUD").collection("ReportData").find();

      // console.log("Converting cursor to array...");
      result = await cursor.toArray();

      console.log("Fetched data:", result.length, "records found");
      return result;
    } catch (e) {
      console.log("Error fetching data:", e.message);
      result = null;
    } finally {
      console.log("Closing MongoDB connection...");
      await client.close();
      return result;
    }
  },

  addUser: async function addUser(userDetails) {
    try {
      await client.connect();
      const result = await client
        .db("KVAR-CLOUD")
        .collection("registers")
        .insertOne(userDetails);
      console.log("User added:", result);
      return result;
    } catch (e) {
      console.log("Error adding user:", e);
      return null;
    } finally {
      await client.close();
    }
  },
  fetchAllUsers: async function fetchAllUsers() {
    var result = null;
    var cursor = null;
    try {
      await client.connect();
      cursor = await client.db("KVAR-CLOUD").collection("registers").find();
      result = await cursor.toArray(); // Convert the cursor to an array
      return result;
    } catch (e) {
      console.log("Error fetching user by ID:", e);
      result = null;
    } finally {
      await client.close();
      return result;
    }
  },
  deleteUser: async function deleteUser(id) {
    try {
      await client.connect();
      const result = await client
        .db("KVAR-CLOUD")
        .collection("registers")
        .deleteOne({ _id: new ObjectId(id) });
      console.log("User deleted:", result);
      return result;
    } catch (e) {
      console.log("Error deleting user:", e);
      return null;
    } finally {
      await client.close();
    }
  },
  editUser: async function editUser(id, user) {
    let val = true;

    try {
      await client.connect();
      const result = await client
        .db("KVAR-CLOUD")
        .collection("registers")
        .findOneAndUpdate(
          { _id: new ObjectId(id) },
          {
            $set: {
              companyName: user.companyName,
              Address: user.address,
              Plan: user.plan,
              Website: user.website,
              contactNo: user.contactNo,
              phoneNo: user.phoneNo,
              AltPhoneNo: user.altPhoneNo,
              email: user.email,
              altEmail: user.altEmail,
            },
          },
          { returnOriginal: false }
        );
      return result;
    } catch (e) {
      console.log(e);
      val = false;
    } finally {
      await client.close();
      return val;
    }
  },
  updatePassword: async function updatePassword(email, newPassword) {
    let result = null;
    try {
      await client.connect();
      result = await client
        .db("KVAR-CLOUD")
        .collection("registers")
        .findOneAndUpdate(
          { email: email },
          { $set: { password: newPassword, defaultPwd: "1" } },
          { returnDocument: "after" } // Optionally, you can get the updated document
        );
    } catch (e) {
      console.log("Error updating password:", e);
      result = null;
    } finally {
      await client.close();
      return result;
    }
  },
  updatePasswordById: async function updatePasswordById(id, newPassword) {
    let result = null;
    try {
      await client.connect();
      result = await client
        .db("KVAR-CLOUD")
        .collection("registers")
        .findOneAndUpdate(
          { _id: new ObjectId(id) },
          {
            $set: {
              password: newPassword,
              defaultPwd: "0",
            },
          },
          { returnDocument: "after" } // Optionally, you can get the updated document
        );
    } catch (e) {
      console.log("Error updating password by ID:", e);
      result = null;
    } finally {
      await client.close();
      return result;
    }
  },
  editPlant: async function editPlant(id, user) {
    let val = true;

    try {
      await client.connect();
      const result = await client
        .db("KVAR-CLOUD")
        .collection("registers")
        .findOneAndUpdate(
          { _id: new ObjectId(id) },
          {
            $set: {
              plantName: user.plantName,
              plantIncharge: user.plantIncharge,
              address: user.address,
              location: user.location,
              phoneNo: user.phoneNo,
              AltPhoneNo: user.altPhoneNo,
              email: user.email,
              altEmail: user.altEmail,
            },
          },
          { returnOriginal: false }
        );
      return result;
    } catch (e) {
      console.log(e);
      val = false;
    } finally {
      await client.close();
      return val;
    }
  },
  editSupervisor: async function editSupervisor(id, user) {
    let val = true;

    try {
      await client.connect();
      const result = await client
        .db("KVAR-CLOUD")
        .collection("registers")
        .findOneAndUpdate(
          { _id: new ObjectId(id) },
          {
            $set: {
              userName: user.userName,
              activityStatus: user.activityStatus,
              phoneNo: user.phoneNo,
              AltPhoneNo: user.altPhoneNo,
              email: user.email,
              altEmail: user.altEmail,
              type: user.adminLevel,
            },
          },
          { returnOriginal: false }
        );
      return result;
    } catch (e) {
      console.log(e);
      val = false;
    } finally {
      await client.close();
      return val;
    }
  },
  addTool: async function addTool(toolDetails) {
    try {
      await client.connect();
      const result = await client
        .db("KVAR-CLOUD")
        .collection("toolLifeMaster")
        .insertOne(toolDetails);
      console.log("Tool added:", result);
      return result;
    } catch (e) {
      console.log("Error adding tool:", e);
      return null;
    } finally {
      await client.close();
    }
  },
  fetchTools: async function fetchTools(companyId, plantId) {
    let result = null;
    try {
      await client.connect();
      result = await client
        .db("KVAR-CLOUD")
        .collection("toolLifeMaster")
        .find({
          companyId: companyId,
          plantId: plantId,
        })
        .toArray();
    } catch (e) {
      console.log("Error fetching tools:", e);
      result = null;
    } finally {
      await client.close();
      return result;
    }
  },
  fetchToolById: async function fetchToolById(tool) {
    console.log("fetchToolById Called");
    let result = null;
    try {
      await client.connect();
      result = await client
        .db("KVAR-CLOUD")
        .collection("toolLifeMaster")
        .findOne({
          _id: new ObjectId(tool), // Convert to ObjectId
        });

      if (result) {
        console.log("Fetched Tool:", result);
        return result.toolName; // Return the toolName directly
      } else {
        console.warn("Tool not found for ID:", tool);
        return null;
      }
    } catch (e) {
      console.error("Error fetching tool:", e);
      return null;
    } finally {
      await client.close();
    }
  },
  editTool: async function editTool(id, tool) {
    let val = true;

    try {
      await client.connect();
      const result = await client
        .db("KVAR-CLOUD")
        .collection("toolLifeMaster")
        .findOneAndUpdate(
          { _id: new ObjectId(id) },
          {
            $set: {
              toolName: tool.toolName,
              toolID: tool.toolID,
              tlLifeHrs: tool.tlLifeHrs,
              description: tool.description,
            },
          },
          { returnOriginal: false }
        );
      return result;
    } catch (e) {
      console.log(e);
      val = false;
    } finally {
      await client.close();
      return val;
    }
  },
  deleteTool: async function deleteTool(id) {
    try {
      await client.connect();
      const result = await client
        .db("KVAR-CLOUD")
        .collection("toolLifeMaster")
        .deleteOne({ _id: new ObjectId(id) });
      console.log("Tool deleted:", result);
      return result;
    } catch (e) {
      console.log("Error deleting tool:", e);
      return null;
    } finally {
      await client.close();
    }
  },
  findToolByObjId: async function findToolByObjId(id) {
    // console.log(id);
    let result = null;
    try {
      await client.connect();
      result = await client
        .db("KVAR-CLOUD")
        .collection("toolLifeMaster")
        .find({
          _id: new ObjectId(id),
        })
        .toArray();
    } catch (e) {
      console.log("Error fetching tools:", e);
      result = null;
    } finally {
      await client.close();
      return result;
    }
  },
  shiftAdd: async function shiftAdd(shiftDetails) {
    try {
      await client.connect();
      const result = await client
        .db("KVAR-CLOUD")
        .collection("shift")
        .insertOne(shiftDetails);
      console.log("Shift added:", result);
      return result;
    } catch (e) {
      console.log("Error adding shift:", e);
      return null;
    } finally {
      await client.close();
    }
  },
  breakAdd: async function breakAdd(breakDetails) {
    try {
      await client.connect();
      const result = await client
        .db("KVAR-CLOUD")
        .collection("shift")
        .insertOne(breakDetails);
      console.log("Break added:", result);
      return result;
    } catch (e) {
      console.log("Error adding break:", e);
      return null;
    } finally {
      await client.close();
    }
  },
  fetchShift: async function fetchShift(companyId, plantId) {
    let result = null;
    try {
      await client.connect();
      result = await client
        .db("KVAR-CLOUD")
        .collection("shift")
        .find({
          companyId: companyId,
          plantId: plantId,
          type: "1",
        })
        .toArray();
    } catch (e) {
      console.log("Error fetching shifts:", e);
      result = null;
    } finally {
      await client.close();
      return result;
    }
  },
  fetchShiftById: async function fetchShiftById(id) {
    let result = null;
    try {
      await client.connect();
      result = await client
        .db("KVAR-CLOUD")
        .collection("shift")
        .find({
          _id: new ObjectId(id),
        })
        .toArray();
    } catch (e) {
      console.log("Error fetching shifts:", e);
      result = null;
    } finally {
      await client.close();
      return result;
    }
  },
  fetchBreak: async function fetchBreak(companyId, plantId) {
    let result = null;
    try {
      await client.connect();
      result = await client
        .db("KVAR-CLOUD")
        .collection("shift")
        .find({
          companyId: companyId,
          plantId: plantId,
          type: "2",
        })
        .toArray();
    } catch (e) {
      console.log("Error fetching breaks:", e);
      result = null;
    } finally {
      await client.close();
      return result;
    }
  },
  deleteShiftBreak: async function deleteShiftBreak(id) {
    try {
      await client.connect();
      const result = await client
        .db("KVAR-CLOUD")
        .collection("shift")
        .deleteOne({ _id: new ObjectId(id) });
      console.log("Shift/Break deleted:", result);
      return result;
    } catch (e) {
      console.log("Error deleting Shift/Break:", e);
      return null;
    } finally {
      await client.close();
    }
  },
  editShift: async function editShift(id, shift) {
    let val = true;

    try {
      await client.connect();
      const result = await client
        .db("KVAR-CLOUD")
        .collection("shift")
        .findOneAndUpdate(
          { _id: new ObjectId(id) },
          {
            $set: {
              shiftName: shift.shiftName,
              shiftTo: shift.shiftTo,
              shiftFrom: shift.shiftFrom,
            },
          },
          { returnOriginal: false }
        );
      return result;
    } catch (e) {
      console.log(e);
      val = false;
    } finally {
      await client.close();
      return val;
    }
  },
  editBreak: async function editBreak(id, break2) {
    let val = true;

    try {
      await client.connect();
      const result = await client
        .db("KVAR-CLOUD")
        .collection("shift")
        .findOneAndUpdate(
          { _id: new ObjectId(id) },
          {
            $set: {
              breakName: break2.breakName,
              breakTo: break2.breakTo,
              breakFrom: break2.breakFrom,
            },
          },
          { returnOriginal: false }
        );
      return result;
    } catch (e) {
      console.log(e);
      val = false;
    } finally {
      await client.close();
      return val;
    }
  },
  productAdd: async function productAdd(product) {
    try {
      await client.connect();
      const result = await client
        .db("KVAR-CLOUD")
        .collection("product")
        .insertOne(product);
      console.log("Product added:", result);
      return result;
    } catch (e) {
      console.log("Error adding break:", e);
      return null;
    } finally {
      await client.close();
    }
  },
  fetchProduct: async function fetchProduct(companyId, plantId) {
    let result = null;
    try {
      await client.connect();
      result = await client
        .db("KVAR-CLOUD")
        .collection("product")
        .find({
          companyId: companyId,
          plantId: plantId,
        })
        .toArray();
    } catch (e) {
      console.log("Error fetching tools:", e);
      result = null;
    } finally {
      await client.close();
      return result;
    }
  },
  fetchProductById: async function fetchProductById(id) {
    let result = null;
    //console.log("Product:ID",id);
    try {
      await client.connect();
      result = await client
        .db("KVAR-CLOUD")
        .collection("product")
        .find({
          _id: new ObjectId(id),
        })
        .toArray();
    } catch (e) {
      console.log("Error fetching tools:", e);
      result = null;
    } finally {
      await client.close();
      return result;
    }
  },
  // fetchRecipesById: async function fetchRecipesById(id) {
  //   let result = null;
  //   //console.log("Product:ID",id);
  //   try {
  //     await client.connect();
  //     result = await client
  //       .db("KVAR-CLOUD")
  //       .collection("recipes")
  //       .find({
  //         _id: new ObjectId(id),
  //       })
  //       .toArray();
  //   } catch (e) {
  //     console.log("Error fetching tools:", e);
  //     result = null;
  //   } finally {
  //     await client.close();
  //     return result;
  //   }
  // },

  fetchRecipesById: async function fetchRecipesById(id) {
    let result = null;
    //console.log("Product:ID",id);
    try {
      await client.connect();
      result = await client
        .db("KVAR-CLOUD")
        .collection("recipes")
        .find({
          _id: new ObjectId(id),
        })
        .toArray();
    } catch (e) {
      console.log("Error fetching tools:", e);
      result = null;
    } finally {
      await client.close();
      return result;
    }
  },
  recipeAdd: async function recipeAdd(recipe) {
    try {
      await client.connect();
      const result = await client
        .db("KVAR-CLOUD")
        .collection("recipes")
        .insertOne(recipe);
      console.log("Recipe added:", result);
      return result;
    } catch (e) {
      console.log("Error adding recipe:", e);
      return null;
    } finally {
      await client.close();
    }
  },
  fetchRecipes: async function fetchReipes(companyId, plantId) {
    let result = null;
    try {
      await client.connect();
      result = await client
        .db("KVAR-CLOUD")
        .collection("recipes")
        .find({
          companyId: companyId,
          plantId: plantId,
        })
        .toArray();
    } catch (e) {
      console.log("Error fetching recipes:", e);
      result = null;
    } finally {
      await client.close();
      return result;
    }
  },

  fetchRecipeByProductName: async function fetchRecipeByProductName(
    companyId,
    plantId,
    productName
  ) {
    let result = null;
    try {
      await client.connect();
      result = await client
        .db("KVAR-CLOUD")
        .collection("recipes")
        .find({
          companyId: companyId,
          plantId: plantId,
          productName: productName,
        })
        .toArray();
    } catch (e) {
      console.log("Error fetching recipes:", e);
      result = null;
    } finally {
      await client.close();
      return result;
    }
  },
  deleteRecipe: async function deleteRecipe(id) {
    try {
      await client.connect();
      const result = await client
        .db("KVAR-CLOUD")
        .collection("recipes")
        .deleteOne({ _id: new ObjectId(id) });
      console.log("Recipe deleted:", result);
      return result;
    } catch (e) {
      console.log("Error deleting Recipe:", e);
      return null;
    } finally {
      await client.close();
    }
  },
  deleteProduct: async function deleteProduct(id) {
    try {
      await client.connect();
      const result = await client
        .db("KVAR-CLOUD")
        .collection("product")
        .deleteOne({ _id: new ObjectId(id) });
      console.log("Recipe deleted:", result);
      const result2 = await client
        .db("KVAR-CLOUD")
        .collection("recipes")
        .deleteMany({ productName: id });
      console.log("Products deleted:", result2.deletedCount);
      return result;
    } catch (e) {
      console.log("Error deleting Recipe:", e);
      return null;
    } finally {
      await client.close();
    }
  },
  editRecipe: async function editRecipe(id, recipe) {
    let val = true;

    try {
      await client.connect();
      const result = await client
        .db("KVAR-CLOUD")
        .collection("recipes")
        .findOneAndUpdate(
          { _id: new ObjectId(id) },
          {
            $set: {
              productName: recipe.productName,
              toolName: recipe.toolName,
              process: recipe.process,
              description: recipe.description,
              apr: recipe.apr,
              prs: recipe.prs,
              strokes: recipe.strokes,
              cyclic: recipe.cyclic,
              delay: recipe.delay,
            },
          },
          { returnOriginal: false }
        );
      return result;
    } catch (e) {
      console.log(e);
      val = false;
    } finally {
      await client.close();
      return val;
    }
  },
  deviceAdd: async function deviceAdd(devices) {
    try {
      await client.connect();
      const result = await client
        .db("KVAR-CLOUD")
        .collection("devices")
        .insertOne(devices);
      console.log("Devices added:", result);
      return result;
    } catch (e) {
      console.log("Error adding devices:", e);
      return null;
    } finally {
      await client.close();
    }
  },
  fetchDevices: async function fetchDevices(companyId, plantId) {
    let result = null;
    try {
      await client.connect();
      result = await client
        .db("KVAR-CLOUD")
        .collection("devices")
        .find({
          companyId: companyId,
          plantId: plantId,
        })
        .toArray();
    } catch (e) {
      console.log("Error fetching devices:", e);
      result = null;
    } finally {
      await client.close();
      return result;
    }
  },
  fetchDeviceById: async function fetchDeviceById(deviceId) {
    let result = null;
    try {
      await client.connect();
      result = await client.db("KVAR-CLOUD").collection("devices").findOne({
        deviceId: deviceId, // Convert the string ID to ObjectId
      });
    } catch (e) {
      console.log("Error fetching device:", e);
      result = null;
    } finally {
      await client.close();
      return result;
    }
  },
  fetchDeviceByObjId: async function fetchDeviceByObjId(deviceId) {
    let result = null;
    try {
      await client.connect();
      result = await client
        .db("KVAR-CLOUD")
        .collection("devices")
        .findOne({
          _id: new ObjectId(deviceId), // Convert the string ID to ObjectId
        });
    } catch (e) {
      console.log("Error fetching device:", e);
      result = null;
    } finally {
      await client.close();
      return result;
    }
  },
  editDevice: async function editDevice(id, device) {
    let val = true;

    try {
      await client.connect();
      const result = await client
        .db("KVAR-CLOUD")
        .collection("devices")
        .findOneAndUpdate(
          { _id: new ObjectId(id) },
          {
            $set: {
              deviceName: device.deviceName,
              model: device.model,
              location: device.location,
              deviceId: device.deviceId,
              macId: device.macId,
              serialNumber: device.serialNumber,
              mfgDate: device.mfgDate,
            },
          },
          { returnOriginal: false }
        );
      return result;
    } catch (e) {
      console.log(e);
      val = false;
    } finally {
      await client.close();
      return val;
    }
  },
  deleteDevice: async function deleteDevice(id) {
    try {
      await client.connect();
      const result = await client
        .db("KVAR-CLOUD")
        .collection("devices")
        .deleteOne({ _id: new ObjectId(id) });
      console.log("Recipe deleted:", result);

      return result;
    } catch (e) {
      console.log("Error deleting Recipe:", e);
      return null;
    } finally {
      await client.close();
    }
  },
  enableDevice: async function enableDevice(id, state) {
    let val = true;

    try {
      await client.connect();
      const result = await client
        .db("KVAR-CLOUD")
        .collection("devices")
        .findOneAndUpdate(
          { _id: new ObjectId(id) },
          {
            $set: {
              enable: state,
            },
          },
          { returnOriginal: false }
        );
      return result;
    } catch (e) {
      console.log(e);
      val = false;
    } finally {
      await client.close();
      return val;
    }
  },
  addModel: async function addModel(model) {
    try {
      await client.connect();
      const result = await client
        .db("KVAR-CLOUD")
        .collection("models")
        .insertOne(model);
      console.log("Models added:", result);
      return result;
    } catch (e) {
      console.log("Error adding model:", e);
      return null;
    } finally {
      await client.close();
    }
  },
  fetchAllModels: async function fetchAllModels() {
    var result = null;
    var cursor = null;
    try {
      await client.connect();
      cursor = await client.db("KVAR-CLOUD").collection("models").find();
      result = await cursor.toArray(); // Convert the cursor to an array
      return result;
    } catch (e) {
      console.log("Error fetching models", e);
      result = null;
    } finally {
      await client.close();
      return result;
    }
  },
  fetchAllModelsParms: async function fetchAllModelsParms() {
    var result = null;
    var cursor = null;
    try {
      await client.connect();
      cursor = await client.db("KVAR-CLOUD").collection("modelPara").find();
      result = await cursor.toArray(); // Convert the cursor to an array
      return result;
    } catch (e) {
      console.log("Error fetching models", e);
      result = null;
    } finally {
      await client.close();
      return result;
    }
  },
  addModelPara: async function addModelPara(model) {
    try {
      await client.connect();
      const result = await client
        .db("KVAR-CLOUD")
        .collection("modelPara")
        .insertOne(model);
      console.log("Model Para added:", result);
      return result;
    } catch (e) {
      console.log("Error adding model para:", e);
      return null;
    } finally {
      await client.close();
    }
  },
  fetchModelParms: async function fetchModelParms(modelId) {
    let result = null;
    try {
      await client.connect();
      result = await client.db("KVAR-CLOUD").collection("modelPara").findOne({
        modelId: modelId,
      });
    } catch (e) {
      console.log("Error fetching devices:", e);
      result = null;
    } finally {
      await client.close();
      return result;
    }
  },
  deleteModel: async function deleteModel(id) {
    try {
      await client.connect();
      const result = await client
        .db("KVAR-CLOUD")
        .collection("modelPara")
        .deleteOne({ _id: new ObjectId(id) });

      console.log("Model:", result);

      return result;
    } catch (e) {
      console.log("Error deleting Model:", e);
      return null;
    } finally {
      await client.close();
    }
  },
  lineAdd: async function lineAdd(product) {
    try {
      await client.connect();
      const result = await client
        .db("KVAR-CLOUD")
        .collection("lines")
        .insertOne(product);
      console.log("Line added:", result);
      return result;
    } catch (e) {
      console.log("Error adding Line:", e);
      return null;
    } finally {
      await client.close();
    }
  },
  lineAllocation: async function lineAllocation(line) {
    try {
      await client.connect();
      const result = await client
        .db("KVAR-CLOUD")
        .collection("allocatedLines")
        .insertOne(line);
      console.log("Line added:", result);
      return result;
    } catch (e) {
      console.log("Error adding Line:", e);
      return null;
    } finally {
      await client.close();
    }
  },
  fetchAllocatedLines: async function fetchAllocatedLines() {
    var result = null;
    var cursor = null;
    try {
      await client.connect();
      cursor = await client
        .db("KVAR-CLOUD")
        .collection("allocatedLines")
        .find();
      result = await cursor.toArray();
      return result;
    } catch (e) {
      console.log("Error fetching lines by ID:", e);
      result = null;
    } finally {
      await client.close();
      return result;
    }
  },
  fetchAllLines: async function fetchAllLines(companyId, plantId) {
    var result = null;
    var cursor = null;
    try {
      await client.connect();
      cursor = await client.db("KVAR-CLOUD").collection("lines").find({
        companyId: companyId,
        plantId: plantId,
      });
      result = await cursor.toArray();
      return result;
    } catch (e) {
      console.log("Error fetching lines by ID:", e);
      result = null;
    } finally {
      await client.close();
      return result;
    }
  },
  fetchAllLines2: async function fetchAllLines() {
    var result = null;
    var cursor = null;
    try {
      await client.connect();
      cursor = await client.db("KVAR-CLOUD").collection("lines").find();
      result = await cursor.toArray();
      return result;
    } catch (e) {
      console.log("Error fetching lines by ID:", e);
      result = null;
    } finally {
      await client.close();
      return result;
    }
  },
  deleteLine: async function deleteLine(id) {
    try {
      await client.connect();
      const result = await client
        .db("KVAR-CLOUD")
        .collection("lines")
        .deleteOne({ _id: new ObjectId(id) });
      console.log("Line deleted:", result);
      // const result2 = await client.db("KVAR-CLOUD").collection("allocatedLines").deleteMany({ lineID: id });
      // console.log("Allcocated Lines deleted:", result2.deletedCount);
    } catch (e) {
      console.log("Error deleting Lines:", e);
      return null;
    } finally {
      await client.close();
    }

    try {
      await client.connect();
      const result2 = await client
        .db("KVAR-CLOUD")
        .collection("allocatedLines")
        .deleteMany({ lineID: id });
      console.log("Allcocated Lines deleted:", result2.deletedCount);
      return result2;
    } catch (e) {
      console.log("Error deleting Lines:", e);
      return null;
    } finally {
      await client.close();
    }
  },
  deleteLineDevice: async function deleteLineDevice(id, index) {
    try {
      await client.connect();
      const result = await client
        .db("KVAR-CLOUD")
        .collection("allocatedLines")
        .updateOne(
          { _id: new ObjectId(id) },
          { $unset: { [`deviceId.${index}`]: 1 } } // Unset the specific index
        );

      // Now remove any `null` values from the array
      const cleanResult = await client
        .db("KVAR-CLOUD")
        .collection("allocatedLines")
        .updateOne(
          { _id: new ObjectId(id) },
          { $pull: { deviceId: null } } // Remove null values from the array
        );

      console.log("Device removed from Line:", cleanResult);
      return cleanResult;
    } catch (e) {
      console.log("Error deleting Device from Line:", e);
      return null;
    } finally {
      await client.close();
    }
  },
  getDeviceIdArrayIndex: async function getDeviceIdArrayIndex(
    documentId,
    deviceIdToFind
  ) {
    try {
      await client.connect();

      // Convert the documentId to ObjectId
      const objectId = new ObjectId(documentId);

      // Fetch the document
      const document = await client
        .db("KVAR-CLOUD")
        .collection("allocatedLines")
        .findOne({ _id: objectId });

      // Check if document was found
      if (!document) {
        console.log("Document not found");
        return null;
      }

      // Get the deviceId array
      const deviceIdArray = document.deviceId || [];
      console.log("Device Id:", deviceIdArray);
      var index = 0;
      // Find the index of the specified deviceId
      for (i = 0; deviceIdArray.length; i++) {
        if (deviceIdArray[i] == new ObjectId(deviceIdToFind)) {
          return index;
        } else {
          index++;
        }
      }

      // Return the index
      return index;
    } catch (e) {
      console.log("Error getting Device ID array index:", e);
      return null;
    } finally {
      await client.close();
    }
  },
  updateDeviceInLine: async function updateDeviceInLine(
    id,
    beforeDeviceId,
    afterDeviceId,
    index
  ) {
    try {
      await client.connect();

      // Convert string IDs to ObjectId
      const objectId = new ObjectId(id);
      const beforeDeviceObjectId = new ObjectId(beforeDeviceId);

      const result = await client
        .db("KVAR-CLOUD")
        .collection("allocatedLines")
        .updateOne(
          { _id: new ObjectId(id) },
          { $unset: { [`deviceId.${index}`]: 1 } } // Unset the specific index
        );

      // Now remove any `null` values from the array
      const cleanResult = await client
        .db("KVAR-CLOUD")
        .collection("allocatedLines")
        .updateOne(
          { _id: new ObjectId(id) },
          { $pull: { deviceId: null } } // Remove null values from the array
        );

      //console.log("Device removed:", result);

      // Add the afterDeviceId to the deviceId array
      const addResult = await client
        .db("KVAR-CLOUD")
        .collection("allocatedLines")
        .updateOne(
          {
            _id: objectId,
          },
          {
            $addToSet: { deviceId: afterDeviceId }, // Add the new deviceId if not already present
          }
        );

      //console.log("Device added:", addResult);

      return {
        result,
        addResult,
      };
    } catch (e) {
      console.log("Error updating Device in Line:", e);
      return null;
    } finally {
      await client.close();
    }
  },
  fetchDevicesInLine: async function fetchDevicesInLine(lineId) {
    try {
      await client.connect();

      // Fetch the line data using the provided lineId
      const lineData = await client
        .db("KVAR-CLOUD")
        .collection("allocatedLines")
        .findOne({ lineID: lineId });

      if (lineData) {
        return lineData.deviceId || []; // Return the array of device IDs if found
      } else {
        return []; // Return an empty array if no devices are found
      }
    } catch (e) {
      console.log("Error fetching Devices in Line:", e);
      return null;
    } finally {
      await client.close();
    }
  },
  fetchDataInLine: async function fetchDataInLine(lineId) {
    try {
      await client.connect();

      // Fetch the line data using the provided lineId
      const lineData = await client
        .db("KVAR-CLOUD")
        .collection("allocatedLines")
        .findOne({ lineID: lineId });

      return lineData;
    } catch (e) {
      console.log("Error fetching Devices in Line:", e);
      return null;
    } finally {
      await client.close();
    }
  },
  editLineMain: async function editLineMain(id, lineId, lineName) {
    let val = true;

    try {
      await client.connect();
      const result = await client
        .db("KVAR-CLOUD")
        .collection("lines")
        .findOneAndUpdate(
          { _id: new ObjectId(id) },
          {
            $set: {
              lineId: lineId,
              lineName: lineName,
            },
          },
          { returnOriginal: false }
        );
      return result;
    } catch (e) {
      console.log(e);
      val = false;
    } finally {
      await client.close();
      return val;
    }
  },
  fetchLineById: async function fetchLineById(line) {
    let result = null;
    try {
      await client.connect();
      result = await client.db("KVAR-CLOUD").collection("lines").findOne({
        lineId: line, // Convert the string ID to ObjectId
      });
    } catch (e) {
      console.log("Error fetching device:", e);
      result = null;
    } finally {
      await client.close();
      return result;
    }
  },
  fetchLineByOgId: async function fetchLineByOgId(id) {
    let result = null;
    try {
      await client.connect();
      result = await client
        .db("KVAR-CLOUD")
        .collection("allocatedLines")
        .findOne({
          _id: new ObjectId(id), // Convert the string ID to ObjectId
        });
    } catch (e) {
      console.log("Error fetching device:", e);
      result = null;
    } finally {
      await client.close();
      return result;
    }
  },
  editLineAllocation: async function editLineAllocation(id, lineId) {
    let val = true;

    try {
      await client.connect();
      const result = await client
        .db("KVAR-CLOUD")
        .collection("allocatedLines")
        .findOneAndUpdate(
          { _id: new ObjectId(id) },
          {
            $set: {
              lineId: lineId,
            },
          },
          { returnOriginal: false }
        );
      return result;
    } catch (e) {
      console.log(e);
      val = false;
    } finally {
      await client.close();
      return val;
    }
  },
  fetchAllocatedLineById: async function fetchAllocatedLineById(line) {
    let result = null;
    try {
      await client.connect();
      result = await client
        .db("KVAR-CLOUD")
        .collection("allocatedLines")
        .findOne({
          lineID: line,
        });
    } catch (e) {
      console.log("Error fetching device:", e);
      result = null;
    } finally {
      await client.close();
      return result;
    }
  },
  dailyPlanning: async function dailyPlanning(dailyPlanning) {
    try {
      await client.connect();
      const result = await client
        .db("KVAR-CLOUD")
        .collection("DailyPlanning")
        .insertOne(dailyPlanning);
      console.log("Added:", result);
      return result;
    } catch (e) {
      console.log("Error adding:", e);
      return null;
    } finally {
      await client.close();
    }
  },
  fetchAllPlanning: async function fetchAllPlanning() {
    var result = null;
    var cursor = null;
    try {
      await client.connect();
      cursor = await client.db("KVAR-CLOUD").collection("DailyPlanning").find();
      result = await cursor.toArray();
      return result;
    } catch (e) {
      console.log("Error fetching planning by ID:", e);
      result = null;
    } finally {
      await client.close();
      return result;
    }
  },
  fetchPlanningByDate: async function fetchPlanningByDate(
    companyId,
    plantId,
    date
  ) {
    var result = null;
    var cursor = null;
    try {
      await client.connect();
      cursor = await client.db("KVAR-CLOUD").collection("DailyPlanning").find({
        companyId: companyId,
        plantId: plantId,
        date: date,
      });
      result = await cursor.toArray();
      return result;
    } catch (e) {
      console.log("Error fetching planning by ID:", e);
      result = null;
    } finally {
      await client.close();
      return result;
    }
  },
  deleteTodayPlanning: async function deleteTodayPlanning(id) {
    try {
      await client.connect();
      const result = await client
        .db("KVAR-CLOUD")
        .collection("DailyPlanning")
        .deleteOne({ _id: new ObjectId(id) });
      console.log("Today's deleted:", result);
      return result;
    } catch (e) {
      console.log("Error deleting Today's Planning:", e);
      return null;
    } finally {
      await client.close();
    }
  },
  PlanningPerDeviceRecipeLine: async function PlanningPerDeviceRecipeLine(
    details
  ) {
    try {
      await client.connect();

      // Extract the relevant fields for the query
      const { companyId, plantId, date, lineId, deviceId, recipeId, shiftId } =
        details;

      // Query to check if the record already exists
      const existingRecord = await client
        .db("KVAR-CLOUD")
        .collection("finalPlanning")
        .findOne({
          companyId: companyId,
          plantId: plantId,
          date: date,
          lineId: { $in: lineId },
          deviceId: { $in: deviceId },
          recipeId: { $in: recipeId },
          shiftId: { $in: shiftId },
        });

      if (existingRecord) {
        // If the record exists, first remove the existing productionTarget and operatingHours
        await client
          .db("KVAR-CLOUD")
          .collection("finalPlanning")
          .updateOne(
            { _id: existingRecord._id },
            {
              $unset: {
                productionTarget: "",
                operatingHours: "",
              },
            }
          );

        // Then push the new values
        const updatedRecord = await client
          .db("KVAR-CLOUD")
          .collection("finalPlanning")
          .updateOne(
            { _id: existingRecord._id },
            {
              $set: {
                productionTarget: details.productionTarget,
                operatingHours: details.operatingHours,
              },
            }
          );
        console.log("Record updated:", updatedRecord);
        return updatedRecord;
      } else {
        // If the record does not exist, insert the new record
        const result = await client
          .db("KVAR-CLOUD")
          .collection("finalPlanning")
          .insertOne(details);
        console.log("Line added:", result);
        return result;
      }
    } catch (e) {
      console.log("Error adding final planning:", e);
      return null;
    } finally {
      await client.close();
    }
  },
  fetchFinalPlanning: async function fetchFinalPlanning(
    companyId,
    plantId,
    date
  ) {
    var result = null;
    var cursor = null;
    try {
      await client.connect();
      cursor = await client.db("KVAR-CLOUD").collection("finalPlanning").find({
        companyId: companyId,
        plantId: plantId,
        date: date,
      });
      result = await cursor.toArray();
      return result;
    } catch (e) {
      console.log("Error fetching planning by ID:", e);
      result = null;
    } finally {
      await client.close();
      return result;
    }
  },
  addDeviceData: async function addDeviceData(data) {
    try {
      await client.connect();
      const result = await client
        .db("KVAR-CLOUD")
        .collection("deviceData")
        .insertOne(data);
      // console.log("Device Data added:", result);
      return result;
    } catch (e) {
      console.log("Error adding device data", e);
      return null;
    } finally {
      await client.close();
    }
  },
  appendFinalPlanning: async function appendFinalPlanning(
    companyId,
    plantId,
    date,
    index,
    parameters,
    operatingActual,
    productionActual
  ) {
    // console.log("Params" , parameters);
    try {
      // console.log("Connecting to MongoDB...");
      await client.connect();
      // console.log("Connected to MongoDB!");

      const db = client.db("KVAR-CLOUD");
      const collection = db.collection("finalPlanning");

      // Define filter and update objects
      const filter = {
        companyId: companyId,
        plantId: plantId,
        date: date,
      };

      const update = {
        $set: {
          [`parameters.${index}`]: parameters,
          [`operatingActual.${index}`]: operatingActual,
          [`productionActual.${index}`]: productionActual,
        },
      };

      // console.log("Filter:", JSON.stringify(filter, null, 2));
      // console.log("Update:", JSON.stringify(update, null, 2));

      // Check if a document exists before updating
      const existingDoc = await collection.findOne(filter);
      if (!existingDoc) {
        // console.warn("No matching document found for the given filter.");
      } else {
        // console.log("Existing document found:", JSON.stringify(existingDoc, null, 2));
      }

      const options = { returnDocument: "after" }; // Use 'after' instead of 'returnOriginal: false'

      // console.log("Executing findOneAndUpdate...");
      const result = await collection.findOneAndUpdate(filter, update, options);

      // console.log("Raw result from findOneAndUpdate:", result);

      if (!result || !result.value) {
        // console.error("No document was updated. result.value is undefined.");
        return null;
      }

      // console.log("Updated Document:", JSON.stringify(result.value, null, 2));
      return result.value;
    } catch (error) {
      console.error("Error appending final planning data:", error);
    } finally {
      // console.log("Closing MongoDB connection...");
      await client.close();
    }
  },
  changeShift: async function changeShift(
    companyId,
    plantId,
    date,
    currentShift,
    deviceId
  ) {
    try {
      await client.connect();
      const db = client.db("KVAR-CLOUD");
      const collection = db.collection("finalPlanning");

      const filter = {
        companyId: companyId,
        plantId: plantId,
        date: date,
      };

      const planning = await collection.findOne(filter);

      if (!planning) {
        throw new Error("No planning data found for the given criteria.");
      }

      const index = planning.deviceId.findIndex(
        (id, idx) => id === deviceId && planning.shiftId[idx] === currentShift
      );

      if (index === -1) {
        throw new Error("No matching deviceId and shiftId found.");
      }

      if (planning.activeProcess[index] === "0") {
        // Update activeProcess to 1 for the found index
        planning.activeProcess[index] = "1";

        // Find the index of the previous activeProcess 1 and set it to 2
        const prevActiveIndex = planning.activeProcess.findIndex(
          (ap) => ap === "1" && planning.deviceId[ap] !== deviceId
        );

        if (prevActiveIndex !== -1) {
          planning.activeProcess[prevActiveIndex] = "2";
        }

        const update = {
          $set: {
            activeProcess: planning.activeProcess,
          },
        };

        const options = { returnOriginal: false };
        const result = await collection.findOneAndUpdate(
          filter,
          update,
          options
        );
        return true; // Returns the updated document
      } else if (planning.activeProcess[index] === "1") {
        return false; // No update needed, return the current planning
      }
    } catch (error) {
      console.error("Error changing shift:", error);
    } finally {
      await client.close();
    }
  },
};
