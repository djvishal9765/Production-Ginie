const { MongoClient } = require('mongodb');

class MongoDBSessionStore {
    constructor(uri, dbName, collectionName) {
        this.client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });
        this.dbName = dbName;
        this.collectionName = collectionName;
    }

    async connect() {
        if (!this.db) {
            await this.client.connect();
            this.db = this.client.db(this.dbName);
            this.collection = this.db.collection(this.collectionName);
        }
    }

    async get(sessionId) {
        await this.connect();
        const session = await this.collection.findOne({ _id: sessionId });
        return session ? session.session : null;
    }

    async set(sessionId, sessionData) {
        await this.connect();
        await this.collection.updateOne(
            { _id: sessionId },
            { $set: { session: sessionData, lastModified: new Date() } },
            { upsert: true }
        );
    }

    async destroy(sessionId) {
        await this.connect();
        await this.collection.deleteOne({ _id: sessionId });
    }

    async all() {
        await this.connect();
        return this.collection.find({}).toArray();
    }

    async length() {
        await this.connect();
        return this.collection.countDocuments();
    }
}

module.exports = MongoDBSessionStore;
