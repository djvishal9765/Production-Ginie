const dotenv = require("dotenv");
dotenv.config();
const { MongoClient, ObjectId } = require("mongodb");
const uri = process.env.DATABASE_URL;
let client = new MongoClient(uri, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
let db;

// Function to ensure connection persistence
async function connectDB() {
  try {
    if (
      !client ||
      !client.topology ||
      client.topology.s.state !== "connected"
    ) {
      console.log("Connecting to MongoDB...");
      client = new MongoClient(uri, {
        useNewUrlParser: true,
        useUnifiedTopology: true,
      });

      await client.connect();
      console.log("Successfully connected to MongoDB");
      db = client.db("KVAR-CLOUD");
    } else {
      //console.log("Using existing MongoDB connection");
    }
  } catch (error) {
    console.error("MongoDB connection error:", error);
    throw error;
  }
  return db;
}

async function testConnection() {
  try {
    await connectDB();
    console.log("Successfully connected to MongoDB");
    return true;
  } catch (e) {
    console.error("Failed to connect to MongoDB", e);
    return false;
  }
}

module.exports = {
  testConnection,
  fetchUserID: async function fetchUserID(id) {
    try {
      const database = await connectDB();
      return await database
        .collection("registers")
        .findOne({ _id: new ObjectId(id) });
    } catch (error) {
      console.error("Error fetching user by ID:", error);
      return null;
    }
  },
  fetchUserEmail: async function fetchUserEmail(email) {
    try {
      const database = await connectDB();
      return await database.collection("registers").findOne({ email: email });
    } catch (error) {
      console.error("Error fetching user by email:", error);
      return null;
    }
  },
  addUser: async function addUser(userDetails) {
    try {
      const database = await connectDB();
      const result = await database
        .collection("registers")
        .insertOne(userDetails);
      console.log("User added:", result);
      return result;
    } catch (error) {
      console.error("Error adding user:", error);
      return null;
    }
  },
  fetchAllUsers: async function fetchAllUsers() {
    try {
      const database = await connectDB();
      const cursor = await database.collection("registers").find();
      return await cursor.toArray();
    } catch (error) {
      console.error("Error fetching all users:", error);
      return null;
    }
  },
  deleteUser: async function deleteUser(id) {
    try {
      const database = await connectDB();
      const result = await database
        .collection("registers")
        .deleteOne({ _id: new ObjectId(id) });
      console.log("User deleted:", result);
      return result;
    } catch (error) {
      console.error("Error deleting user:", error);
      return null;
    }
  },
  editUser: async function editUser(id, user) {
    try {
      const database = await connectDB();
      const result = await database.collection("registers").findOneAndUpdate(
        { _id: new ObjectId(id) },
        {
          $set: {
            companyName: user.companyName,
            Address: user.address,
            Plan: user.plan,
            Website: user.website,
            contactNo: user.contactNo,
            phoneNo: user.phoneNo,
            AltPhoneNo: user.altPhoneNo,
            email: user.email,
            altEmail: user.altEmail,
          },
        },
        { returnOriginal: false }
      );
      return result;
    } catch (error) {
      console.error("Error editing user:", error);
      return false;
    }
  },
  addReportData: async function addReportData(
    currentShift,

    companyId,
    plantId,

    deviceId,
    date,
    parameters,
    operatingActual,
    productionActual
  ) {
    try {
      console.log("Connecting to the database");
      await client.connect();

      const todayStart = new Date(date);
      todayStart.setHours(0, 0, 0, 0);

      const operatingActualInt = parseInt(operatingActual, 10) || 0;
      const productionActualInt = parseInt(productionActual, 10) || 0;

      console.log("Checking if an existing report exists");
      const existingReport = await client
        .db("KVAR-CLOUD")
        .collection("ReportData")
        .findOne({
          companyId: companyId,
          plantId: plantId,
          deviceId: deviceId,
          currentShift: currentShift,
          date: todayStart,
        });

      if (existingReport) {
        console.log("Updating existing report");
        const updatedData = {
          $set: {
            updatedAt: new Date(),
            parameters: parameters || [],
          },
          $inc: {
            operatingActual: operatingActualInt,
            productionActual: productionActualInt,
          },
        };

        const updateResult = await client
          .db("KVAR-CLOUD")
          .collection("ReportData")
          .updateOne({ _id: existingReport._id }, updatedData);

        console.log("Existing report updated", updateResult.modifiedCount);
        return existingReport._id;
      } else {
        console.log("Creating new report");
        const reportData = {
          companyId: companyId,
          plantId: plantId,
          currentShift: currentShift,
          deviceId: deviceId,
          date: todayStart,
          parameters: parameters || [],
          operatingActual: operatingActualInt,
          productionActual: productionActualInt,
          createdAt: new Date(),
          updatedAt: new Date(),
        };

        const result = await client
          .db("KVAR-CLOUD")
          .collection("ReportData")
          .insertOne(reportData);

        console.log("New report data added", result.insertedId);
        return result.insertedId;
      }
    } catch (e) {
      console.error("Error adding/updating report data", e.message);
      return null;
    } finally {
      console.log("Closing database connection");
      await client.close();
    }
  },
  updatePassword: async function updatePassword(email, newPassword) {
    try {
      const database = await connectDB();
      const result = await database
        .collection("registers")
        .findOneAndUpdate(
          { email: email },
          { $set: { password: newPassword, defaultPwd: "1" } },
          { returnDocument: "after" }
        );
      return result;
    } catch (error) {
      console.error("Error updating password:", error);
      return null;
    }
  },
  updatePasswordById: async function updatePasswordById(id, newPassword) {
    try {
      const database = await connectDB();
      const result = await database.collection("registers").findOneAndUpdate(
        { _id: new ObjectId(id) },
        {
          $set: {
            password: newPassword,
            defaultPwd: "0",
          },
        },
        { returnDocument: "after" }
      );
      return result;
    } catch (error) {
      console.error("Error updating password by ID:", error);
      return null;
    }
  },
  editPlant: async function editPlant(id, user) {
    try {
      const database = await connectDB();
      const result = await database.collection("registers").findOneAndUpdate(
        { _id: new ObjectId(id) },
        {
          $set: {
            plantName: user.plantName,
            plantIncharge: user.plantIncharge,
            address: user.address,
            location: user.location,
            phoneNo: user.phoneNo,
            AltPhoneNo: user.altPhoneNo,
            email: user.email,
            altEmail: user.altEmail,
          },
        },
        { returnOriginal: false }
      );
      return result;
    } catch (error) {
      console.error("Error editing plant:", error);
      return false;
    }
  },
  editSupervisor: async function editSupervisor(id, user) {
    try {
      const database = await connectDB();
      const result = await database.collection("registers").findOneAndUpdate(
        { _id: new ObjectId(id) },
        {
          $set: {
            userName: user.userName,
            activityStatus: user.activityStatus,
            phoneNo: user.phoneNo,
            AltPhoneNo: user.altPhoneNo,
            email: user.email,
            altEmail: user.altEmail,
            type: user.adminLevel,
          },
        },
        { returnOriginal: false }
      );
      return result;
    } catch (error) {
      console.error("Error editing supervisor:", error);
      return false;
    }
  },
  addTool: async function addTool(toolDetails) {
    try {
      const database = await connectDB();
      const result = await database
        .collection("toolLifeMaster")
        .insertOne(toolDetails);
      console.log("Tool added:", result);
      return result;
    } catch (error) {
      console.error("Error adding tool:", error);
      return null;
    }
  },
  fetchTools: async function fetchTools(companyId, plantId) {
    try {
      const database = await connectDB();
      return await database
        .collection("toolLifeMaster")
        .find({
          companyId: companyId,
          plantId: plantId,
        })
        .toArray();
    } catch (error) {
      console.error("Error fetching tools:", error);
      return null;
    }
  },
  editTool: async function editTool(id, tool) {
    try {
      const database = await connectDB();
      const result = await database
        .collection("toolLifeMaster")
        .findOneAndUpdate(
          { _id: new ObjectId(id) },
          {
            $set: {
              toolName: tool.toolName,
              toolID: tool.toolID,
              tlLifeHrs: tool.tlLifeHrs,
              description: tool.description,
            },
          },
          { returnOriginal: false }
        );
      return result;
    } catch (error) {
      console.error("Error editing tool:", error);
      return false;
    }
  },
  deleteTool: async function deleteTool(id) {
    try {
      const database = await connectDB();
      const result = await database
        .collection("toolLifeMaster")
        .deleteOne({ _id: new ObjectId(id) });
      console.log("Tool deleted:", result);
      return result;
    } catch (error) {
      console.error("Error deleting tool:", error);
      return null;
    }
  },
  findToolByObjId: async function findToolByObjId(id) {
    try {
      const database = await connectDB();
      return await database
        .collection("toolLifeMaster")
        .find({
          _id: new ObjectId(id),
        })
        .toArray();
    } catch (error) {
      console.error("Error fetching tool by ObjectId:", error);
      return null;
    }
  },
  shiftAdd: async function shiftAdd(shiftDetails) {
    try {
      const database = await connectDB();
      const result = await database.collection("shift").insertOne(shiftDetails);
      console.log("Shift added:", result);
      return result;
    } catch (error) {
      console.error("Error adding shift:", error);
      return null;
    }
  },
  breakAdd: async function breakAdd(breakDetails) {
    try {
      const database = await connectDB();
      const result = await database.collection("shift").insertOne(breakDetails);
      console.log("Break added:", result);
      return result;
    } catch (error) {
      console.error("Error adding break:", error);
      return null;
    }
  },
  fetchShift: async function fetchShift(companyId, plantId) {
    try {
      const database = await connectDB();
      return await database
        .collection("shift")
        .find({
          companyId: companyId,
          plantId: plantId,
          type: "1",
        })
        .toArray();
    } catch (error) {
      console.error("Error fetching shifts:", error);
      return null;
    }
  },
  fetchShiftById: async function fetchShiftById(id) {
    try {
      const database = await connectDB();
      return await database
        .collection("shift")
        .find({
          _id: new ObjectId(id),
        })
        .toArray();
    } catch (error) {
      console.error("Error fetching shift by ID:", error);
      return null;
    }
  },
  fetchBreak: async function fetchBreak(companyId, plantId) {
    try {
      const database = await connectDB();
      return await database
        .collection("shift")
        .find({
          companyId: companyId,
          plantId: plantId,
          type: "2",
        })
        .toArray();
    } catch (error) {
      console.error("Error fetching breaks:", error);
      return null;
    }
  },
  deleteShiftBreak: async function deleteShiftBreak(id) {
    try {
      const database = await connectDB();
      const result = await database
        .collection("shift")
        .deleteOne({ _id: new ObjectId(id) });
      console.log("Shift/Break deleted:", result);
      return result;
    } catch (error) {
      console.error("Error deleting Shift/Break:", error);
      return null;
    }
  },
  editShift: async function editShift(id, shift) {
    try {
      const database = await connectDB();
      const result = await database.collection("shift").findOneAndUpdate(
        { _id: new ObjectId(id) },
        {
          $set: {
            shiftName: shift.shiftName,
            shiftTo: shift.shiftTo,
            shiftFrom: shift.shiftFrom,
          },
        },
        { returnOriginal: false }
      );
      return result;
    } catch (error) {
      console.error("Error editing shift:", error);
      return false;
    }
  },
  editBreak: async function editBreak(id, break2) {
    try {
      const database = await connectDB();
      const result = await database.collection("shift").findOneAndUpdate(
        { _id: new ObjectId(id) },
        {
          $set: {
            breakName: break2.breakName,
            breakTo: break2.breakTo,
            breakFrom: break2.breakFrom,
          },
        },
        { returnOriginal: false }
      );
      return result;
    } catch (error) {
      console.error("Error editing break:", error);
      return false;
    }
  },
  productAdd: async function productAdd(product) {
    try {
      const database = await connectDB();
      const result = await database.collection("product").insertOne(product);
      console.log("Product added:", result);
      return result;
    } catch (error) {
      console.error("Error adding product:", error);
      return null;
    }
  },
  fetchProduct: async function fetchProduct(companyId, plantId) {
    try {
      const database = await connectDB();
      return await database
        .collection("product")
        .find({
          companyId: companyId,
          plantId: plantId,
        })
        .toArray();
    } catch (error) {
      console.error("Error fetching products:", error);
      return null;
    }
  },
  fetchProductById: async function fetchProductById(id) {
    try {
      const database = await connectDB();
      return await database
        .collection("product")
        .find({
          _id: new ObjectId(id),
        })
        .toArray();
    } catch (error) {
      console.error("Error fetching product by ID:", error);
      return null;
    }
  },
  fetchRecipesById: async function fetchRecipesById(id) {
    try {
      const database = await connectDB();
      return await database
        .collection("recipes")
        .find({
          _id: new ObjectId(id),
        })
        .toArray();
    } catch (error) {
      console.error("Error fetching recipes by ID:", error);
      return null;
    }
  },
  recipeAdd: async function recipeAdd(recipe) {
    try {
      const database = await connectDB();
      const result = await database.collection("recipes").insertOne(recipe);
      console.log("Recipe added:", result);
      return result;
    } catch (error) {
      console.error("Error adding recipe:", error);
      return null;
    }
  },
  fetchRecipes: async function fetchRecipes(companyId, plantId) {
    try {
      const database = await connectDB();
      return await database
        .collection("recipes")
        .find({
          companyId: companyId,
          plantId: plantId,
        })
        .toArray();
    } catch (error) {
      console.error("Error fetching recipes:", error);
      return null;
    }
  },
  fetchRecipeByProductName: async function fetchRecipeByProductName(
    companyId,
    plantId,
    productName
  ) {
    try {
      const database = await connectDB();
      return await database
        .collection("recipes")
        .find({
          companyId: companyId,
          plantId: plantId,
          productName: productName,
        })
        .toArray();
    } catch (error) {
      console.error("Error fetching recipes by product name:", error);
      return null;
    }
  },
  deleteRecipe: async function deleteRecipe(id) {
    try {
      const database = await connectDB();
      const result = await database
        .collection("recipes")
        .deleteOne({ _id: new ObjectId(id) });
      console.log("Recipe deleted:", result);
      return result;
    } catch (error) {
      console.error("Error deleting recipe:", error);
      return null;
    }
  },
  deleteProduct: async function deleteProduct(id) {
    try {
      const database = await connectDB();
      const result = await database
        .collection("product")
        .deleteOne({ _id: new ObjectId(id) });
      console.log("Product deleted:", result);
      const result2 = await database
        .collection("recipes")
        .deleteMany({ productName: id });
      console.log("Products deleted:", result2.deletedCount);
      return result;
    } catch (error) {
      console.error("Error deleting product:", error);
      return null;
    }
  },
  editRecipe: async function editRecipe(id, recipe) {
    try {
      const database = await connectDB();
      const result = await database.collection("recipes").findOneAndUpdate(
        { _id: new ObjectId(id) },
        {
          $set: {
            productName: recipe.productName,
            toolName: recipe.toolName,
            process: recipe.process,
            description: recipe.description,
            apr: recipe.apr,
            prs: recipe.prs,
            strokes: recipe.strokes,
            cyclic: recipe.cyclic,
            delay: recipe.delay,
          },
        },
        { returnOriginal: false }
      );
      return result;
    } catch (error) {
      console.error("Error editing recipe:", error);
      return false;
    }
  },
  deviceAdd: async function deviceAdd(devices) {
    try {
      const database = await connectDB();
      const result = await database.collection("devices").insertOne(devices);
      console.log("Devices added:", result);
      return result;
    } catch (error) {
      console.error("Error adding devices:", error);
      return null;
    }
  },
  fetchDevices: async function fetchDevices(companyId, plantId) {
    try {
      const database = await connectDB();
      return await database
        .collection("devices")
        .find({
          companyId: companyId,
          plantId: plantId,
        })
        .toArray();
    } catch (error) {
      console.error("Error fetching devices:", error);
      return null;
    }
  },
  fetchDeviceById: async function fetchDeviceById(deviceId) {
    try {
      const database = await connectDB();
      return await database.collection("devices").findOne({
        deviceId: deviceId,
      });
    } catch (error) {
      console.error("Error fetching device by ID:", error);
      return null;
    }
  },
  fetchDeviceByObjId: async function fetchDeviceByObjId(deviceId) {
    try {
      const database = await connectDB();
      return await database.collection("devices").findOne({
        _id: new ObjectId(deviceId),
      });
    } catch (error) {
      console.error("Error fetching device by ObjectId:", error);
      return null;
    }
  },
  editDevice: async function editDevice(id, device) {
    let val = true;
    const database = await connectDB();

    try {
      const result = await database.collection("devices").findOneAndUpdate(
        { _id: new ObjectId(id) },
        {
          $set: {
            deviceName: device.deviceName,
            model: device.model,
            location: device.location,
            deviceId: device.deviceId,
            macId: device.macId,
            serialNumber: device.serialNumber,
            mfgDate: device.mfgDate,
          },
        },
        { returnOriginal: false }
      );
      return result;
    } catch (e) {
      console.log(e);
      val = false;
    } finally {
      return val;
    }
  },

  deleteDevice: async function deleteDevice(id) {
    const database = await connectDB();

    try {
      const result = await database
        .collection("devices")
        .deleteOne({ _id: new ObjectId(id) });
      console.log("Device deleted:", result);
      return result;
    } catch (e) {
      console.log("Error deleting device:", e);
      return null;
    }
  },

  enableDevice: async function enableDevice(id, state) {
    let val = true;
    const database = await connectDB();

    try {
      const result = await database.collection("devices").findOneAndUpdate(
        { _id: new ObjectId(id) },
        {
          $set: {
            enable: state,
          },
        },
        { returnOriginal: false }
      );
      return result;
    } catch (e) {
      console.log(e);
      val = false;
    } finally {
      return val;
    }
  },

  addModel: async function addModel(model) {
    const database = await connectDB();

    try {
      const result = await database.collection("models").insertOne(model);
      console.log("Model added:", result);
      return result;
    } catch (e) {
      console.log("Error adding model:", e);
      return null;
    }
  },

  fetchAllModels: async function fetchAllModels() {
    const database = await connectDB();

    try {
      const cursor = await database.collection("models").find();
      const result = await cursor.toArray();
      return result;
    } catch (e) {
      console.log("Error fetching models:", e);
      return null;
    }
  },

  fetchAllModelsParms: async function fetchAllModelsParms() {
    const database = await connectDB();

    try {
      const cursor = await database.collection("modelPara").find();
      const result = await cursor.toArray();
      return result;
    } catch (e) {
      console.log("Error fetching model parameters:", e);
      return null;
    }
  },

  addModelPara: async function addModelPara(model) {
    const database = await connectDB();

    try {
      const result = await database.collection("modelPara").insertOne(model);
      console.log("Model parameter added:", result);
      return result;
    } catch (e) {
      console.log("Error adding model parameter:", e);
      return null;
    }
  },

  fetchModelParms: async function fetchModelParms(modelId) {
    const database = await connectDB();

    try {
      const result = await database.collection("modelPara").findOne({
        modelId: modelId,
      });
      return result;
    } catch (e) {
      console.log("Error fetching model parameters:", e);
      return null;
    }
  },

  deleteModel: async function deleteModel(id) {
    const database = await connectDB();

    try {
      const result = await database
        .collection("modelPara")
        .deleteOne({ _id: new ObjectId(id) });
      console.log("Model deleted:", result);
      return result;
    } catch (e) {
      console.log("Error deleting model:", e);
      return null;
    }
  },

  lineAdd: async function lineAdd(product) {
    const database = await connectDB();

    try {
      const result = await database.collection("lines").insertOne(product);
      console.log("Line added:", result);
      return result;
    } catch (e) {
      console.log("Error adding line:", e);
      return null;
    }
  },

  lineAllocation: async function lineAllocation(line) {
    const database = await connectDB();

    try {
      const result = await database
        .collection("allocatedLines")
        .insertOne(line);
      console.log("Line allocated:", result);
      return result;
    } catch (e) {
      console.log("Error allocating line:", e);
      return null;
    }
  },

  fetchAllocatedLines: async function fetchAllocatedLines() {
    const database = await connectDB();

    try {
      const cursor = await database.collection("allocatedLines").find();
      const result = await cursor.toArray();
      return result;
    } catch (e) {
      console.log("Error fetching allocated lines:", e);
      return null;
    }
  },

  fetchAllLines: async function fetchAllLines(companyId, plantId) {
    const database = await connectDB();

    try {
      const cursor = await database.collection("lines").find({
        companyId: companyId,
        plantId: plantId,
      });
      const result = await cursor.toArray();
      return result;
    } catch (e) {
      console.log("Error fetching lines:", e);
      return null;
    }
  },

  fetchAllLines2: async function fetchAllLines2() {
    const database = await connectDB();

    try {
      const cursor = await database.collection("lines").find();
      const result = await cursor.toArray();
      return result;
    } catch (e) {
      console.log("Error fetching lines:", e);
      return null;
    }
  },

  deleteLine: async function deleteLine(id) {
    const database = await connectDB();

    try {
      const result = await database
        .collection("lines")
        .deleteOne({ _id: new ObjectId(id) });
      console.log("Line deleted:", result);
      return result;
    } catch (e) {
      console.log("Error deleting line:", e);
      return null;
    }
  },

  deleteLineDevice: async function deleteLineDevice(id, index) {
    const database = await connectDB();

    try {
      const result = await database
        .collection("allocatedLines")
        .updateOne(
          { _id: new ObjectId(id) },
          { $unset: { [`deviceId.${index}`]: 1 } }
        );

      const cleanResult = await database
        .collection("allocatedLines")
        .updateOne({ _id: new ObjectId(id) }, { $pull: { deviceId: null } });

      console.log("Device removed from line:", cleanResult);
      return cleanResult;
    } catch (e) {
      console.log("Error deleting device from line:", e);
      return null;
    }
  },

  getDeviceIdArrayIndex: async function getDeviceIdArrayIndex(
    documentId,
    deviceIdToFind
  ) {
    const database = await connectDB();

    try {
      const objectId = new ObjectId(documentId);
      const document = await database
        .collection("allocatedLines")
        .findOne({ _id: objectId });

      if (!document) {
        console.log("Document not found");
        return null;
      }

      const deviceIdArray = document.deviceId || [];
      for (let i = 0; i < deviceIdArray.length; i++) {
        if (deviceIdArray[i].toString() === deviceIdToFind) {
          return i;
        }
      }
      return null;
    } catch (e) {
      console.log("Error getting device ID array index:", e);
      return null;
    }
  },

  updateDeviceInLine: async function updateDeviceInLine(
    id,
    beforeDeviceId,
    afterDeviceId,
    index
  ) {
    const database = await connectDB();

    try {
      const objectId = new ObjectId(id);
      const beforeDeviceObjectId = new ObjectId(beforeDeviceId);

      const result = await database
        .collection("allocatedLines")
        .updateOne({ _id: objectId }, { $unset: { [`deviceId.${index}`]: 1 } });

      const cleanResult = await database
        .collection("allocatedLines")
        .updateOne({ _id: objectId }, { $pull: { deviceId: null } });

      const addResult = await database
        .collection("allocatedLines")
        .updateOne(
          { _id: objectId },
          { $addToSet: { deviceId: afterDeviceId } }
        );

      return { result, addResult };
    } catch (e) {
      console.log("Error updating device in line:", e);
      return null;
    }
  },

  fetchDevicesInLine: async function fetchDevicesInLine(lineId) {
    const database = await connectDB();

    try {
      const lineData = await database
        .collection("allocatedLines")
        .findOne({ lineID: lineId });

      if (lineData) {
        return lineData.deviceId || [];
      } else {
        return [];
      }
    } catch (e) {
      console.log("Error fetching devices in line:", e);
      return null;
    }
  },

  fetchDataInLine: async function fetchDataInLine(lineId) {
    const database = await connectDB();

    try {
      const lineData = await database
        .collection("allocatedLines")
        .findOne({ lineID: lineId });

      return lineData;
    } catch (e) {
      console.log("Error fetching data in line:", e);
      return null;
    }
  },

  editLineMain: async function editLineMain(id, lineId, lineName) {
    let val = true;
    const database = await connectDB();

    try {
      const result = await database.collection("lines").findOneAndUpdate(
        { _id: new ObjectId(id) },
        {
          $set: {
            lineId: lineId,
            lineName: lineName,
          },
        },
        { returnOriginal: false }
      );
      return result;
    } catch (e) {
      console.log(e);
      val = false;
    } finally {
      return val;
    }
  },

  fetchLineById: async function fetchLineById(line) {
    const database = await connectDB();

    try {
      const result = await database.collection("lines").findOne({
        lineId: line,
      });
      return result;
    } catch (e) {
      console.log("Error fetching line by ID:", e);
      return null;
    }
  },

  fetchLineByOgId: async function fetchLineByOgId(id) {
    const database = await connectDB();

    try {
      const result = await database
        .collection("allocatedLines")
        .findOne({ _id: new ObjectId(id) });
      return result;
    } catch (e) {
      console.log("Error fetching line by ObjectId:", e);
      return null;
    }
  },

  editLineAllocation: async function editLineAllocation(id, lineId) {
    let val = true;
    const database = await connectDB();

    try {
      const result = await database
        .collection("allocatedLines")
        .findOneAndUpdate(
          { _id: new ObjectId(id) },
          {
            $set: {
              lineId: lineId,
            },
          },
          { returnOriginal: false }
        );
      return result;
    } catch (e) {
      console.log(e);
      val = false;
    } finally {
      return val;
    }
  },

  fetchAllocatedLineById: async function fetchAllocatedLineById(line) {
    const database = await connectDB();

    try {
      const result = await database
        .collection("allocatedLines")
        .findOne({ lineID: line });
      return result;
    } catch (e) {
      console.log("Error fetching allocated line by ID:", e);
      return null;
    }
  },

  dailyPlanning: async function dailyPlanning(dailyPlanning) {
    const database = await connectDB();

    try {
      const result = await database
        .collection("DailyPlanning")
        .insertOne(dailyPlanning);
      console.log("Daily planning added:", result);
      return result;
    } catch (e) {
      console.log("Error adding daily planning:", e);
      return null;
    }
  },

  fetchAllPlanning: async function fetchAllPlanning() {
    const database = await connectDB();

    try {
      const cursor = await database.collection("DailyPlanning").find();
      const result = await cursor.toArray();
      return result;
    } catch (e) {
      console.log("Error fetching all planning:", e);
      return null;
    }
  },

  fetchPlanningByDate: async function fetchPlanningByDate(
    companyId,
    plantId,
    date
  ) {
    const database = await connectDB();

    try {
      const cursor = await database.collection("DailyPlanning").find({
        companyId: companyId,
        plantId: plantId,
        date: date,
      });
      const result = await cursor.toArray();
      return result;
    } catch (e) {
      console.log("Error fetching planning by date:", e);
      return null;
    }
  },

  deleteTodayPlanning: async function deleteTodayPlanning(id) {
    const database = await connectDB();

    try {
      const result = await database
        .collection("DailyPlanning")
        .deleteOne({ _id: new ObjectId(id) });
      console.log("Today's planning deleted:", result);
      return result;
    } catch (e) {
      console.log("Error deleting today's planning:", e);
      return null;
    }
  },

  PlanningPerDeviceRecipeLine: async function PlanningPerDeviceRecipeLine(
    details
  ) {
    const database = await connectDB();

    try {
      const { companyId, plantId, date, lineId, deviceId, recipeId, shiftId } =
        details;

      const existingRecord = await database
        .collection("finalPlanning")
        .findOne({
          companyId: companyId,
          plantId: plantId,
          date: date,
          lineId: { $in: lineId },
          deviceId: { $in: deviceId },
          recipeId: { $in: recipeId },
          shiftId: { $in: shiftId },
        });

      if (existingRecord) {
        await database.collection("finalPlanning").updateOne(
          { _id: existingRecord._id },
          {
            $unset: {
              productionTarget: "",
              operatingHours: "",
            },
          }
        );

        const updatedRecord = await database
          .collection("finalPlanning")
          .updateOne(
            { _id: existingRecord._id },
            {
              $set: {
                productionTarget: details.productionTarget,
                operatingHours: details.operatingHours,
              },
            }
          );
        console.log("Record updated:", updatedRecord);
        return updatedRecord;
      } else {
        const result = await database
          .collection("finalPlanning")
          .insertOne(details);
        // console.log("Final planning added:", result);
        return result;
      }
    } catch (e) {
      console.log("Error adding final planning:", e);
      return null;
    }
  },

  fetchFinalPlanning: async function fetchFinalPlanning(
    companyId,
    plantId,
    date
  ) {
    const database = await connectDB();

    try {
      const cursor = await database.collection("finalPlanning").find({
        companyId: companyId,
        plantId: plantId,
        date: date,
      });
      const result = await cursor.toArray();
      return result;
    } catch (e) {
      console.log("Error fetching final planning:", e);
      return null;
    }
  },

  addDeviceData: async function addDeviceData(data) {
    const database = await connectDB();

    try {
      const result = await database.collection("deviceData").insertOne(data);
      console.log("Device data added:", result);
      return result;
    } catch (e) {
      console.log("Error adding device data:", e);
      return null;
    }
  },

  appendFinalPlanning: async function appendFinalPlanning(
    companyId,
    plantId,
    date,
    index,
    parameters,
    operatingActual,
    productionActual
  ) {
    const database = await connectDB();

    try {
      const filter = {
        companyId: companyId,
        plantId: plantId,
        date: date,
      };

      const update = {
        $set: {
          [`parameters.${index}`]: parameters,
          [`operatingActual.${index}`]: operatingActual,
          [`productionActual.${index}`]: productionActual,
        },
      };

      const options = { returnOriginal: false };

      const result = await database
        .collection("finalPlanning")
        .findOneAndUpdate(filter, update, options);
      return result.value;
    } catch (error) {
      console.error("Error appending final planning data:", error);
    }
  },
  changeShift: async function changeShift(
    companyId,
    plantId,
    date,
    currentShift,
    deviceId
  ) {
    const database = await connectDB();

    try {
      const filter = {
        companyId: companyId,
        plantId: plantId,
        date: date,
      };

      const planning = await database
        .collection("finalPlanning")
        .findOne(filter);

      if (!planning) {
        throw new Error("No planning data found for the given criteria.");
      }

      const index = planning.deviceId.findIndex(
        (id, idx) => id === deviceId && planning.shiftId[idx] === currentShift
      );

      if (index === -1) {
        throw new Error("No matching deviceId and shiftId found.");
      }

      if (planning.activeProcess[index] === "0") {
        planning.activeProcess[index] = "1";

        const prevActiveIndex = planning.activeProcess.findIndex(
          (ap) => ap === "1" && planning.deviceId[ap] !== deviceId
        );

        if (prevActiveIndex !== -1) {
          planning.activeProcess[prevActiveIndex] = "2";
        }

        const update = {
          $set: {
            activeProcess: planning.activeProcess,
          },
        };

        const options = { returnOriginal: false };
        const result = await database
          .collection("finalPlanning")
          .findOneAndUpdate(filter, update, options);
        return true;
      } else if (planning.activeProcess[index] === "1") {
        return false;
      }
    } catch (error) {
      console.error("Error changing shift:", error);
    }
  },
  startProcess: async function startProcess(startDetails) {
    const database = await connectDB();

    try {
      // Check if an entry already exists for the same deviceId
      const existingEntry = await database
        .collection("startLogs")
        .findOne({ deviceId: startDetails.deviceId });

      if (existingEntry) {
        // Update existing entry
        const updateResult = await database.collection("startLogs").updateOne(
          { deviceId: startDetails.deviceId },
          {
            $set: {
              status: startDetails.status,
              time: startDetails.time,
              updatedAt: new Date(),
            },
          }
        );

        console.log("Existing entry updated:", updateResult);
        return updateResult;
      } else {
        // Insert a new entry if not found
        const insertResult = await database.collection("startLogs").insertOne({
          deviceId: startDetails.deviceId,
          status: startDetails.status,
          time: startDetails.time,
          createdAt: new Date(),
        });

        console.log("New entry added:", insertResult);
        return insertResult;
      }
    } catch (e) {
      console.error("Error processing start process:", e);
      return null;
    }
  },
  fetchStartLogs: async function fetchStartLogs(filters = {}) {
    try {
      console.log("Fetching start logs with filters:", filters); // Debug: Input filters

      const database = await connectDB();
      console.log("Database connection established."); // Debug: Connection success

      const query = {};
      if (filters.companyId) query.companyId = filters.companyId;
      if (filters.plantId) query.plantId = filters.plantId;
      if (filters.deviceId) query.deviceId = filters.deviceId; // Optional filter

      const result = await database
        .collection("startLogs")
        .find(query)
        .toArray();

      console.log("Fetched start logs:", result.length, "records found."); // Debug: Query result count

      return result;
    } catch (error) {
      console.error("Error fetching start logs:", error);
      return null;
    }
  },
};
